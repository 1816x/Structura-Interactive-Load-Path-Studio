# Método de desarrollo con agentes

Una forma de construir software con Claude Code (y, si quieres, Codex) en la que
**la IA no recuerda nada y aun así el proyecto no pierde el hilo**. El estado
vive en ficheros del repositorio y no en la conversación; cada cambio pasa por
revisores con un criterio fijo; y el usuario decide lo que llega a `main`.

Este repositorio trae la plantilla que se copia a cada proyecto, los diez
verificadores, los comandos y las skills de diseño. No trae ninguna
infraestructura: cómo levantas tus máquinas es cosa tuya.

---

## La idea en cinco líneas

1. **Cada proyecto en su propia máquina virtual, con su propio repositorio.** Si
   un agente rompe algo, rompe esa máquina y nada más. Se pausa y se retoma sin
   perder nada, y se destruye cuando el proyecto termina.
2. **La conversación es desechable; `.proyecto/` es la memoria.** Toda sesión
   empieza con `/retomar` y termina con `/guardar`.
3. **Quien conduce no teclea código del producto.** Planea, escribe el encargo y
   revisa el diff. El código lo escribe otro motor (`encargar`). Un hook lo hace
   cumplir.
4. **Nada se da por hecho sin ejecutar su comprobación.** Razonar que algo
   funciona no es comprobarlo.
5. **Tres niveles de rama:** `tarea/…` (se tira sin coste), `staging` (del
   agente, donde se integra) y `main` (del usuario; el agente no llega).

---

## Qué hay aquí

| | |
|---|---|
| `plantilla-proyecto/` | Lo que se copia a la raíz de cada repositorio nuevo |
| `plantilla-proyecto/CLAUDE.md` | Las reglas del proyecto. Las lee Claude Code siempre |
| `plantilla-proyecto/AGENTS.md` | Lo mismo para Codex, cuando conduce él |
| `plantilla-proyecto/.proyecto/` | La memoria del proyecto (abajo) |
| `plantilla-proyecto/.claude/commands/` | Los comandos `/retomar`, `/planear`… |
| `plantilla-proyecto/.claude/agents/` | Los diez verificadores |
| `plantilla-proyecto/.agents/skills/`, `.codex/agents/` | Los mismos comandos y verificadores, para Codex |
| `skills/` | Skills de diseño: van en `~/.claude/skills/` de la máquina, no en el repo del proyecto |
| `herramientas/` | Los scripts pequeños que la plantilla da por instalados, y `generar-codex.py` |
| `comprobar-fugas.sh` | La guardia de este repositorio: falla si algo interno se coló |

---

## Los cuatro ficheros de `.proyecto/`

| | |
|---|---|
| `que-hacemos.md` | Qué se construye, para quién, qué queda fuera |
| `como-lo-hacemos.md` | Decisiones **y por qué**, con lo descartado |
| `tareas.md` | Estado de cada tarea y cómo se comprueba |
| `diario.md` | Qué se hizo, qué se descubrió, qué **no** funcionó |

Y dos de apoyo: `estilo.md` (cómo se escribe la documentación) e `ia.yaml`
(qué motores y cuentas usan los scripts). Cuando hay interfaz aparece un quinto,
`diseno.md`, el manual de la interfaz (lo crea la skill `pantallas`).

---

## Los comandos

| | |
|---|---|
| `/retomar` | **¿Dónde me quedé?** Con esto empieza toda sesión |
| `/planear` | **¿Qué construimos y cómo?** Una vez, al principio |
| `/trabajar` | **Haz lo siguiente.** Una tarea, comprobada y anotada |
| `/guardar` | **Me voy.** Con esto termina toda sesión |
| `/revisar` | **¿Los apuntes siguen siendo verdad?** Cada pocas sesiones |
| `/modonoche` | Que siga trabajando sola mientras duermes, sin preguntarte nada (necesita el vigilante, abajo) |
| `/mododia` | Que siga trabajando sola con tú despierto: recicla el contexto cuando haga falta y la empuja si se queda parada. Sí te pregunta |
| `/diseno` | **Esto de la pantalla no me gusta.** Se arregla en todas y no se repite |

Proyecto nuevo: `/planear` una vez, luego `/trabajar` tantas veces como haga
falta, y `/guardar` al irte. Al volver, `/retomar`.

---

## Los diez verificadores

Son personas con un criterio, no ayudantes genéricos. Su respuesta es una
opinión, no una orden.

| | Cuándo se llama |
|---|---|
| `abogado-del-diablo` | Al cerrar un diseño, antes de construirlo. Busca por dónde se rompe |
| `paranoico` | Antes de fusionar a `main`, y en la tarea si toca secretos. Secretos, permisos, puertos y datos que no debían salir |
| `senior-dev` | Sobre cada diff que vuelve de un encargo. Separa lo que bloquea de lo que es mejora o gusto |
| `auditor` | Sobre cambios que tocan dinero, fechas o totales. Escribe casos incómodos y los corre |
| `antislop` | Antes de dar por buena documentación. Solo quita |
| `verificador-docs` | Cuando algo «no cuadra». Contrasta cada afirmación contra el disco |
| `disenador-interfaz` | Antes de escribir una pantalla: qué se enseña y en qué orden |
| `inspector-pantalla` | Después: ¿está bien construida y es como las demás? |
| `usuario-novato` | ¿Puedo terminar mi trabajo sin saber nada de la app? |
| `usuario-experto` | ¿Cuánto me cuesta repetirlo cada día? |

Ninguna pantalla se da por terminada sin el «sí» de `usuario-novato` y
`usuario-experto`.

---

## Los encargos

- **Uno a la vez**, salvo que el usuario pida paralelo con esas palabras. «Hazlo
  todo» habla del alcance, no de lanzar varios: varios encargos con su navegador
  cada uno dejan sin memoria una máquina pequeña. Con `a_la_vez: N` en
  `ia.yaml`, cada encargo va en su propio `git worktree`.
- **Todo encargo lleva:** qué conseguir, qué **no** se toca y **el comando exacto
  que debe pasar**. Un encargo sin criterio de aceptación vuelve mal.
- **Y al final, una lista de nueve comprobaciones** (dos veces, falla a la mitad,
  vacío, valores…). Está en `CLAUDE.md`.
- Si la cuota de Codex se agota, los encargos siguen con Claude, sin preguntar.

---

## El modelo local (opcional)

Un modelo pequeño corriendo en tu red, aislado de internet, con **un solo
trabajo**: material que no debe salir de casa (correo, notas, datos privados).
Para todo lo demás, Codex o Claude aciertan más. Si no lo tienes, borra las
menciones a `ia-local`.

---

## Las skills de diseño

| | |
|---|---|
| `pantallas` | El proceso: el manual de la interfaz, tres niveles según el tamaño del cambio, el modo rescate para apps con muchas pantallas sin manual, y cómo se aprende de lo que dice el usuario. Incluye `gustos/`, los gustos de diseño de quien escribió esto: sustitúyelos por los tuyos |
| `hallmark` | La piel: tipografía, paleta, ritmo, anti-«slop» |
| `marca` | La identidad de una empresa, desde un preset en `marca/presets/<nombre>/`. Viene vacía: el README explica cómo añadir una |

> `hallmark` parte de la skill abierta de Hallmark (licencia MIT, en
> `skills/hallmark/LICENSE`), adaptada a este método.

---

## Las herramientas que la plantilla da por instaladas

Van en el `PATH` de la máquina de desarrollo (p. ej. `~/.local/bin`).

| | Qué hace | Aquí |
|---|---|---|
| `guardia-edicion` | El hook que impide a quien conduce editar ficheros del producto. Permite `.proyecto/`, `.claude/`, `.codex/`, `.agents/` y `ENCARGO*` | ✓ `herramientas/` |
| `tocar-yo` | La salida de emergencia: deja editar a mano y deja rastro (`tocar-yo --fin` lo cierra) | ✓ `herramientas/` |
| `generar-codex.py` | Genera lo de Codex (`.codex/agents/*.toml`, `.agents/skills/`) a partir de `.claude/agents` y `.claude/commands`. Lo de Codex no se edita a mano: se corre esto después de tocar un perfil o un comando | ✓ `herramientas/` |
| `ver-pantalla` | Abre una página con Chrome sin ventana y saca captura, DOM y accesibilidad para los verificadores | ✓ `herramientas/` |
| `encargar` | Lanza un encargo a otro motor (`codex exec`, o `claude -p` con `--claude`), espera, y guarda lo que devolvió. Debe ofrecer `--prueba`, `--fichero`, `--leer`, `--estado`, `--fondo`, `--perfil` y exportar `ENCARGO_MOTOR` al encargado | No: escríbelo para tu entorno |
| `ia-local` | Habla con el modelo local | No: opcional |
| `noche` | El vigilante de `/modonoche` y `/mododia`: modo **noche** (escribe `/trabajar` cada vez que la sesión se para, y `/guardar` + `/clear` + `/retomar` cuando se llena el contexto) y modo **día** (`--dia`: solo recicla con 20 min sin mensajes tuyos y empuja si se queda parada). Necesita `tmux` y que la sesión corra en una sesión tmux con el nombre del repo. `NOCHE_TZ` para la hora del registro | ✓ `herramientas/` |

Y un detector de secretos en el hook `pre-push` de git (p. ej. gitleaks).

---

## Cómo adoptarlo

1. Crea el repositorio del proyecto, con ramas `main` y `staging`.
2. Copia el contenido de `plantilla-proyecto/` a su raíz, incluidos los ficheros
   ocultos: `cp -a plantilla-proyecto/. mi-proyecto/`.
3. Copia `skills/*` a `~/.claude/skills/` de la máquina donde corre la sesión
   (y donde Codex lea sus skills, si lo usas).
4. Instala las herramientas en el `PATH` y escribe tu `encargar`.
5. Ajusta `.proyecto/ia.yaml`: quién conduce, qué cuenta, si hay modelo local.
6. Abre Claude Code en la carpeta y escribe `/planear`.

Lo que no te sirva, quítalo. La regla que más vale de todo esto es la primera:
**el estado en ficheros, no en la conversación.**

---

## Encima de esto, tu capa

Este repositorio es lo genérico. Lo de tu entorno (cómo se fusiona a `main`
allí, dónde corre la producción, tus hooks, tu marca) va en una capa aparte que
pones encima al copiar la plantilla:

- un `.proyecto/casa.md` con lo tuyo, y la línea `@.proyecto/casa.md` al final
  de `CLAUDE.md` (Claude Code importa ficheros así);
- tus hooks en `.claude/settings.local.json`, que Claude Code suma a
  `settings.json`;
- para Codex, que no tiene imports, tu parte añadida al final de `AGENTS.md`.

Así actualizas lo genérico sin pisar lo tuyo, y lo tuyo no acaba aquí.

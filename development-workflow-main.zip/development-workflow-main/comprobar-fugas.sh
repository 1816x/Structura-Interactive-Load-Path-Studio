#!/bin/bash
# La guardia de este repositorio: falla si se coló algo interno.
#
# EL HUECO QUE CIERRA: este método nació dentro de una infraestructura privada
# y se publica reescrito a mano. Una dirección, una ruta o un nombre interno que
# se escape en la reescritura no lo ve nadie a ojo.
#
#   ./comprobar-fugas.sh                   solo la lista genérica (redes, rutas)
#   ./comprobar-fugas.sh --lista FICHERO   además, las palabras de FICHERO
#   ./comprobar-fugas.sh -h                esta ayuda
#
# La lista con los nombres de verdad (máquinas, proyectos, personas) NO va en
# este repositorio: escribirla aquí sería la fuga. Vive con quien publica, y se
# le pasa con --lista: una palabra o expresión por línea, # para comentarios.
# Se buscan como palabras completas, sin distinguir mayúsculas.
#
# Sale 1 si encuentra algo.
# EQUIVALENTE MANUAL: git grep -niwE '<palabras separadas por |>'
set -uo pipefail
cd "$(dirname "$0")"

LISTA=""
case "${1:-}" in
  -h|--help) sed -n '2,19p' "$0" | sed 's/^# \?//'; exit 0 ;;
  --lista) LISTA="${2:?falta el fichero}"; [ -r "$LISTA" ] || { echo "✗ no puedo leer $LISTA"; exit 2; } ;;
  "") ;;
  *) sed -n '2,19p' "$0" | sed 's/^# \?//'; exit 2 ;;
esac

GENERICAS=(
  '192\.168\.[0-9]+\.[0-9]+'
  '10\.[0-9]+\.[0-9]+\.[0-9]+'
  '172\.(1[6-9]|2[0-9]|3[01])\.[0-9]+\.[0-9]+'
  '100\.(6[4-9]|[7-9][0-9]|1[01][0-9]|12[0-7])\.[0-9]+\.[0-9]+'
  'ts\.net' 'proxmox' 'pct' 'qm'
  '/root/' '/srv/' '/mnt/'
  'sops' 'age1[a-z0-9]{20,}'
)
# Excepciones, «fichero:texto de la línea». Cada una con su motivo.
EXCEPCIONES=(
  # hallmark enumera los rangos privados que se niega a abrir (no es una red real)
  'skills/hallmark/references/study.md:Refuse private, loopback'
)

palabras=("${GENERICAS[@]}")
if [ -n "$LISTA" ]; then
  while IFS= read -r l; do
    l="${l%%#*}"; l="$(echo "$l" | sed 's/[[:space:]]*$//')"
    [ -n "$l" ] && palabras+=("$l")
  done < "$LISTA"
fi
patron=$(IFS='|'; echo "${palabras[*]}")

hallado=$(git ls-files -co --exclude-standard -z | grep -zv '^comprobar-fugas.sh$' \
  | xargs -0 grep -niwE "($patron)" -- 2>/dev/null)
for e in "${EXCEPCIONES[@]}"; do
  hallado=$( { printf '%s\n' "$hallado" | grep -vF -- "${e%%:*}:"
               printf '%s\n' "$hallado" | grep -F -- "${e%%:*}:" | grep -vF -- "${e#*:}"; } | sed '/^$/d')
done

if [ -n "$hallado" ]; then
  echo "✗ se coló algo interno:"
  echo "$hallado" | cut -c1-200
  exit 1
fi
echo "✓ sin fugas ($(git ls-files -co --exclude-standard | wc -l) ficheros, ${#palabras[@]} patrones)"

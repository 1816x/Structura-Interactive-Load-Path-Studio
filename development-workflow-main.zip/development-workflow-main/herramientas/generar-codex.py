#!/usr/bin/env python3
"""Genera lo de Codex a partir de lo de Claude, para que sean lo mismo.

EL HUECO QUE CIERRA: la plantilla de proyecto tiene los perfiles en
`.claude/agents/*.md` y los mandatos en `.claude/commands/*.md`. Codex los lee
en otro formato: perfiles en `.codex/agents/*.toml` y mandatos como skills en
`.agents/skills/<n>/SKILL.md`. Hasta el 13-9-2026 esos ficheros decian
«generado de…» pero se habian escrito a mano una vez, y ya diferian. Con dos
copias a mano, al cambiar de orquestador se cambia de criterio sin querer.

QUE MANDA: lo de Claude. Esto se ejecuta despues de tocar `.claude/`; lo de
Codex no se edita nunca a mano. Córrelo después de tocar un perfil o un comando.

Uso:  generar-codex.py [raiz]         escribe (por defecto la plantilla)
      generar-codex.py --ver [raiz]   dice que cambiaria; sale con 1 si difiere
"""
import json, os, re, sys

PLANTILLA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "plantilla-proyecto")
ESCRIBEN = {"Write", "Edit", "MultiEdit", "NotebookEdit"}


def frontmatter(texto):
    """(campos, cuerpo). Los campos son las lineas `clave: valor` del bloque
    entre los dos primeros `---`; el cuerpo es lo que viene despues."""
    m = re.match(r"^---\n(.*?)\n---\n?(.*)$", texto, re.S)
    if not m:
        return {}, texto
    campos = {}
    for l in m.group(1).splitlines():
        k, _, v = l.partition(":")
        if _:
            campos[k.strip()] = v.strip()
    return campos, m.group(2)


def toml_cadena(s):
    # Una cadena basica de TOML escapa igual que JSON para lo que aqui aparece.
    return json.dumps(s, ensure_ascii=False)


def toml_bloque(s):
    # Cadena multilinea basica: hay que escapar la barra y tres comillas.
    s = s.replace("\\", "\\\\").replace('"""', '""\\"')
    return '"""\n' + s.strip("\n") + '\n"""'


def perfil_a_toml(md, origen):
    campos, cuerpo = frontmatter(md)
    herramientas = {h.strip() for h in campos.get("tools", "").split(",") if h.strip()}
    sandbox = "workspace-write" if herramientas & ESCRIBEN else "read-only"
    return (f"# Generado de {origen} por generar-codex.py — NO editar aqui: se pisa.\n"
            f"name = {toml_cadena(campos.get('name', ''))}\n"
            f"description = {toml_cadena(campos.get('description', ''))}\n"
            f"sandbox_mode = {toml_cadena(sandbox)}\n"
            f"developer_instructions = {toml_bloque(cuerpo)}\n")


def mandato_a_skill(md, nombre, origen):
    campos, cuerpo = frontmatter(md)
    return (f"---\nname: {nombre}\ndescription: {campos.get('description', '')}\n---\n\n"
            f"<!-- Generado de {origen} por generar-codex.py: mismo mandato, para Codex. "
            f"Invocalo con ${nombre} o /skills. NO editar aqui: se pisa. -->\n\n"
            + cuerpo.lstrip("\n"))


def previstos(raiz):
    """{ruta destino: contenido} de todo lo que deberia existir."""
    fuera = {}
    d = os.path.join(raiz, ".claude", "agents")
    for f in sorted(os.listdir(d)) if os.path.isdir(d) else []:
        if not f.endswith(".md"):
            continue
        origen = f".claude/agents/{f}"
        with open(os.path.join(d, f), encoding="utf-8") as fh:
            fuera[os.path.join(raiz, ".codex", "agents", f[:-3] + ".toml")] = perfil_a_toml(fh.read(), origen)
    d = os.path.join(raiz, ".claude", "commands")
    for f in sorted(os.listdir(d)) if os.path.isdir(d) else []:
        if not f.endswith(".md"):
            continue
        n = f[:-3]
        with open(os.path.join(d, f), encoding="utf-8") as fh:
            fuera[os.path.join(raiz, ".agents", "skills", n, "SKILL.md")] = mandato_a_skill(fh.read(), n, f".claude/commands/{f}")
    return fuera


def main():
    ver = "--ver" in sys.argv
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    raiz = os.path.abspath(args[0]) if args else PLANTILLA
    quiere = previstos(raiz)
    cambios = 0
    for ruta, contenido in quiere.items():
        try:
            with open(ruta, encoding="utf-8") as fh:
                actual = fh.read()
        except OSError:
            actual = None
        if actual == contenido:
            continue
        cambios += 1
        rel = os.path.relpath(ruta, raiz)
        if ver:
            print(f"  ~ {rel} ({'falta' if actual is None else 'difiere'})")
            continue
        os.makedirs(os.path.dirname(ruta), exist_ok=True)
        with open(ruta, "w", encoding="utf-8") as fh:
            fh.write(contenido)
        print(f"  ✓ {rel}")
    # Lo generado que ya no tiene origen sobra: un perfil borrado de Claude no
    # puede seguir existiendo para Codex.
    for carpeta, ext in ((os.path.join(raiz, ".codex", "agents"), ".toml"),):
        for f in sorted(os.listdir(carpeta)) if os.path.isdir(carpeta) else []:
            ruta = os.path.join(carpeta, f)
            if f.endswith(ext) and ruta not in quiere:
                cambios += 1
                print(f"  - {os.path.relpath(ruta, raiz)} (sin origen en .claude)")
                if not ver:
                    os.remove(ruta)
    skills = os.path.join(raiz, ".agents", "skills")
    for f in sorted(os.listdir(skills)) if os.path.isdir(skills) else []:
        ruta = os.path.join(skills, f, "SKILL.md")
        if os.path.isfile(ruta) and ruta not in quiere:
            cambios += 1
            print(f"  - {os.path.relpath(ruta, raiz)} (sin origen en .claude)")
            if not ver:
                os.remove(ruta)
                try:
                    os.rmdir(os.path.dirname(ruta))
                except OSError:
                    pass
    if cambios == 0:
        print("  ✓ lo de Codex ya es lo de Claude")
    elif ver:
        print(f"  {cambios} ficheros de Codex desactualizados. Regenerar: generar-codex.py")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())

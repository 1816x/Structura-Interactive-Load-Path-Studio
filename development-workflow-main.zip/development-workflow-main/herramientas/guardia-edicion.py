# Decide si el conductor puede escribir en un fichero. Lo llama el hook
# PreToolUse a traves de `guardia-edicion`.
#
# Recibe por la entrada estandar el JSON del hook (de Claude o de Codex) y responde:
#   - sin salida  →  permitido
#   - un JSON con permissionDecision=deny  →  bloqueado, con el motivo
#
# REGLA: los apuntes de orquestacion se escriben aqui; el codigo del producto
# se encarga a Codex, que corre con otra cuota.
import json, os, sys

# Un guardian roto que impide trabajar es peor que uno que deja pasar algo:
# ante cualquier duda, se permite.
try:
    datos = json.load(sys.stdin)
except Exception:
    sys.exit(0)

import re

entrada = datos.get("tool_input") or {}
raiz = os.getcwd()

# QUE FICHEROS TOCA. Claude edita con Edit/Write y trae `file_path`. Codex
# edita con `apply_patch` y trae UN PARCHE: las rutas van dentro, en lineas
# «*** Update File: ruta» / «*** Add File:» / «*** Delete File:» / «*** Move
# to:». Hasta el 13-9-2026 solo se miraba `file_path`, asi que a Codex se le
# dejaba pasar todo sin mirar: la regla «aqui no se teclea codigo» solo valia
# para Claude.
rutas = []
if entrada.get("file_path"):
    rutas.append(str(entrada["file_path"]))
parche = entrada.get("patch") or entrada.get("input") or ""
if isinstance(parche, str) and "*** " in parche:
    rutas += re.findall(r"^\*\*\* (?:Update|Add|Delete) File: (.+?)\s*$", parche, re.M)
    rutas += re.findall(r"^\*\*\* Move to: (.+?)\s*$", parche, re.M)
if not rutas:
    sys.exit(0)


def relativa(ruta):
    try:
        return os.path.relpath(os.path.abspath(ruta), raiz)
    except ValueError:
        return None

# La salida de emergencia. Se pone con `tocar-yo`.
if os.path.exists(os.path.join(raiz, ".proyecto", "editar-yo")):
    sys.exit(0)

# EL ENCARGADO SI TECLEA. Desde el 9-9-2026 `encargar --claude` lanza a Claude
# como programador (subagente del orquestador, sea Codex o Claude). Corre en
# este mismo proyecto con estos mismos hooks, asi que sin esto se bloqueaba a
# si mismo (medido: «no pude completar la edicion»). `encargar` exporta
# ENCARGO_MOTOR; el conductor nunca lo tiene puesto.
if os.environ.get("ENCARGO_MOTOR"):
    sys.exit(0)

PERMITIDO = (".proyecto/", ".claude/", ".codex/", ".agents/")
bloqueadas = []
for ruta in rutas:
    rel = relativa(ruta)
    # Fuera del repositorio no es asunto nuestro: scratch, /tmp, el home.
    if rel is None or rel.startswith(".."):
        continue
    if rel.startswith(PERMITIDO) or os.path.basename(rel).startswith("ENCARGO"):
        continue
    bloqueadas.append(rel)
if not bloqueadas:
    sys.exit(0)
rel = ", ".join(bloqueadas[:4]) + (" …" if len(bloqueadas) > 4 else "")

motivo = (
    "Este fichero es del producto (" + rel + "), y aqui no se teclea codigo.\n\n"
    "El trabajo se encarga a Codex, que corre con otra cuota:\n\n"
    "  encargar \"<que hacer, con criterio de aceptacion>\" <ficheros...>\n\n"
    "El encargo lleva: objetivo, que NO tocar, y el comando exacto que debe\n"
    "pasar. Luego se revisa el diff, y de ahi salen el commit y la propuesta.\n\n"
    "Si de verdad hay que teclearlo aqui (Codex ya fallo dos veces, o no\n"
    "responde): ejecuta  tocar-yo  y vuelve a intentarlo."
)

print(json.dumps({
    "hookSpecificOutput": {
        "hookEventName": "PreToolUse",
        "permissionDecision": "deny",
        "permissionDecisionReason": motivo,
    }
}))

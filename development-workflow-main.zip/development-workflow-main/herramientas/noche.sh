#!/bin/bash
# Modo noche: la sesión del proyecto sigue trabajando sola mientras el usuario duerme.
#
# EL HUECO QUE CIERRA: una sesión se para en cuanto termina una tarea, hace una
# pregunta o se le llena el contexto, y de noche nadie le contesta. El usuario
# lo pidió el 25-10-2026: «que haga guardar, clear y retomar cuando lo necesite,
# para cuando me quede dormido no se detenga».
#
# Corre DENTRO de la maquina del proyecto, en su propia ventana tmux («noche»), y conduce la
# sesión de trabajo («<repo>») tecleando lo que teclearía el usuario. Cada 30 s:
#
#   · trabajando              → no toca nada
#   · parada pero esperando algo en segundo plano (un subagente, una orden
#     larga, un `encargar --fondo`) → nada: cuando termine, sigue sola o la
#     despierta el siguiente /trabajar. Tope: 90 min esperando
#   · un diálogo de Claude    → Esc (nunca acepta nada: ni escaneos ni permisos)
#   · límite de uso           → espera 20 min y vuelve a mirar
#   · el usuario escribió hace menos de 15 min → nada: está despierto y conduce él
#   · parada, contexto lleno o compactado → /guardar · /clear · /retomar · /trabajar
#   · parada                  → /trabajar (la siguiente tarea)
#
# ES UN INTERRUPTOR: sigue encendido hasta que el usuario lo apaga (26-10-2026:
# «es un toggle que yo pongo y quito cuando quiera»; antes tenía hora de fin).
#
# SE PARA SOLA (y antes hace /guardar) solo si:
#   · no quedan tareas pendientes en .proyecto/tareas.md
#   · 3 h sin ningún commit ni encargo corriendo: está atascada, no gasta más
#     (a los 60 min sin avance se aparta 30 min antes de volver a escribirle)
#
# Se arranca DENTRO de la maquina del proyecto, con la sesion corriendo en una
# sesion tmux que se llama como el repo:
#   noche <repo> · noche <repo> --dia · noche --parar · noche --ver
#   noche --viva <repo>: que fichero es la conversacion de la sesion (no un encargo)
#
# MODO DÍA (`noche <repo> --dia`, desde el 5-11-2026): recicla el contexto
# (/guardar · /clear · /retomar) al pasar de 150.000 tokens, con la sesión
# parada y 20 min sin mensajes tuyos, y sigue con /trabajar. Si está por debajo
# del umbral y lleva parada con tareas pendientes 5 min (20 si su último mensaje
# es una pregunta), también /trabajar (con
# freno si no avanza: 3 intentos). No cierra diálogos (podría ser una pregunta
# para ti), y la sesión te sigue preguntando (marca propia, ~/.proyecto-dia).
# Y desde el chat: /modonoche · /mododia (y «parar» o «ver» detrás)
# Mientras está encendido existe ~/.proyecto-noche y la sesión lo sabe (CLAUDE.md,
# «Modo noche»): no pregunta, marca ⛔ lo que necesite al usuario y sigue con otra.
#
# EQUIVALENTE MANUAL: escribirle a la sesión /trabajar cada vez que se pare, y
# /guardar + /clear + /retomar cuando pase de ~250.000 tokens.
set -uo pipefail
# Todos los -t de tmux van con «=»: sin él, tmux acepta un PREFIJO, y
# `kill-session -t noche` mató una sesión «noche-prueba» en la primera prueba.

# Las horas del registro, las del usuario: NOCHE_TZ, o la zona de la maquina
[ -n "${NOCHE_TZ:-}" ] && export TZ="$NOCHE_TZ"
MARCA=~/.proyecto-noche
LOG=~/noche.log
# 150.000 desde el 5-11-2026 (antes 250.000): cada paso de la sesion paga su
# contexto entero, y con la media en ~280k la sesion de un proyecto se llevaba
# el 88 % de los tokens. Retomar cuesta ~50k una vez; seguir con 250k, cada paso.
UMBRAL=${NOCHE_UMBRAL:-150000}   # tokens de contexto a partir de los que se recicla
PAUSA=30   # era 120: de media 1 min parada tras cada tarea, ~25 min por noche (27-10-2026)

# LA CONVERSACION VIVA, NO LA ULTIMA TOCADA (11-11-2026). Los encargos
# (`encargar`) corren en la misma carpeta del repo, asi que su conversacion cae
# en el mismo directorio que la de la sesion. Con «la mas reciente» el
# vigilante medía el contexto de un encargo: en un proyecto, en dos ratos de
# media hora, tecleo /guardar · /clear · /retomar diez veces seguidas a una
# sesion casi vacia, y daba por «20 min sin mensajes tuyos» lo que eran
# mensajes de un encargo. Se descarta toda conversacion cuyo primer mensaje es
# el de un encargo («…al que se le ha ENCARGADO…»).
viva() {
  local f DIRCONV=~/.claude/projects/$(printf '%s' "$HOME/$REPO" | sed 's#[^A-Za-z0-9]#-#g')
  for f in $(ls -t "$DIRCONV"/*.jsonl 2>/dev/null | head -40); do
    python3 - "$f" <<'PY' && { echo "$f"; return 0; }
import json, sys
for l in open(sys.argv[1], errors="replace"):
    try: d = json.loads(l)
    except Exception: continue
    if d.get("type") != "user" or d.get("isMeta"): continue
    c = d.get("message", {}).get("content")
    if isinstance(c, list):
        c = " ".join(x.get("text", "") for x in c if isinstance(x, dict) and x.get("type") == "text")
    if not isinstance(c, str) or not c.strip(): continue
    sys.exit(1 if "se le ha ENCARGADO" in c[:400] else 0)
sys.exit(0)
PY
  done
  return 1
}

case "${1:-}" in
  -h|--help|ayuda|"") sed -n '2,47p' "$0" | sed 's/^# \?//'; exit 0 ;;
  --parar) rm -f "$MARCA" ~/.proyecto-dia; tmux kill-session -t =noche 2>/dev/null; echo "✓ modo noche (o día) apagado"; exit 0 ;;
  # La conversacion de la sesion (no la de un encargo). La usa `proyecto
  # --seguir` para retomar ESA con --resume: `claude --continue` coge la ultima
  # tocada, que puede ser la de un encargo.
  --viva)  REPO="${2:?noche --viva <repo>}"; viva; exit $? ;;
  --ver)   if [ -f "$MARCA" ]; then echo "▸ ENCENDIDO: $(cat "$MARCA")"
           elif [ -f ~/.proyecto-dia ]; then echo "▸ ENCENDIDO: $(cat ~/.proyecto-dia)"; else echo "▸ apagado"; fi
           tail -30 "$LOG" 2>/dev/null; exit 0 ;;
esac

REPO="$1"
[ -d ~/"$REPO" ] || { echo "✗ no existe ~/$REPO"; exit 1; }
# MODO DIA (5-11-2026): recicla el contexto (guardar · clear · retomar ·
# trabajar) al pasar de UMBRAL, cuando la sesion esta parada y el usuario lleva
# 20 min sin escribirle. No cierra dialogos (podria ser una pregunta para el
# usuario) y no se apaga solo. Para no depender de acordarse de limpiar.
MODO="${NOCHE_MODO:-noche}"; [ "${2:-}" = "--dia" ] && MODO=dia
# Su propia marca: con ~/.proyecto-noche la sesion cree que el usuario duerme y
# no le pregunta nada (CLAUDE.md, «Modo noche»). De dia si debe preguntar.
[ "$MODO" = dia ] && MARCA=~/.proyecto-dia && rm -f ~/.proyecto-noche
[ "$MODO" = noche ] && rm -f ~/.proyecto-dia

# Si no estamos ya dentro de la ventana «noche», nos relanzamos en ella.
if [ "${NOCHE_DENTRO:-}" != 1 ]; then
  tmux has-session -t "=$REPO" 2>/dev/null || { echo "✗ no hay sesión de trabajo «$REPO» (proyecto $REPO --seguir)"; exit 1; }
  tmux kill-session -t =noche 2>/dev/null
  echo "$REPO ($MODO), desde $(date '+%d/%m %H:%M'), hasta que el usuario lo apague" > "$MARCA"
  tmux new-session -d -s noche "NOCHE_DENTRO=1 NOCHE_MODO=$MODO $(readlink -f "$0") '$REPO'"
  echo "✓ modo $MODO encendido en $REPO, hasta que lo apagues (noche --parar)"
  exit 0
fi

log() {
  echo "$(date '+%d/%m %H:%M') · $*" >> "$LOG"
  # Lo que pide al usuario mirar (se apaga sola, atascada, sesion perdida), al
  # movil. Lo normal (reciclar, /trabajar) no: seria ruido.
  case "$*" in
    🏁*|⚠*|✗*) command -v avisar >/dev/null && avisar --titulo "$REPO · vigilante" "$*" >/dev/null 2>&1 || true ;;
  esac
}
pantalla() { tmux capture-pane -p -t "=$REPO:" 2>/dev/null | tail -20; }
# Un mensaje suyo enviado mientras la sesion trabaja queda EN COLA y no llega a
# la conversacion (el .jsonl) hasta que ella termina el turno: para usuario_activo
# no existe. El 30-10 a las 15:41 el vigilante tecleo /guardar con un mensaje
# suyo de hacia 40 s esperando en la cola. Claude Code lo dice en pantalla.
en_cola() { pantalla | grep -qiE 'queued message'; }
ocupada() { pantalla | grep -qE 'esc to|Waiting for|ing… *\(|Running [0-9]'; }
dialogo() { pantalla | grep -qE 'Enter to (confirm|continue|select)|Esc to cancel'; }
teclear() { tmux send-keys -t "=$REPO:" -l -- "$1"; sleep 1; tmux send-keys -t "=$REPO:" Enter; }

# Espera a que la sesión termine lo que está haciendo (tope en minutos).
esperar() {
  local tope=$(( ${1:-60} * 6 )) i=0
  sleep 15
  while [ $i -lt "$tope" ]; do
    dialogo && { tmux send-keys -t "=$REPO:" Escape; log "diálogo cerrado con Esc"; }
    ocupada || return 0
    sleep 10; i=$((i+1))
  done
  log "⚠ sigue ocupada tras ${1:-60} min"
}

# El tamaño del contexto: el uso de la última respuesta en la conversación viva.
contexto() {
  local f; f=$(viva)
  [ -n "$f" ] || { echo 0; return; }
  tail -200 "$f" | python3 -c '
import sys, json
t = 0
for l in sys.stdin:
    try: u = json.loads(l).get("message", {}).get("usage")
    except Exception: continue
    if u: t = u.get("input_tokens", 0) + u.get("cache_read_input_tokens", 0) + u.get("cache_creation_input_tokens", 0)
print(t)'
}

# ¿Escribió el usuario hace poco? Sus mensajes (también los de Remote Control)
# están en la conversación; los del vigilante llevan «MODO NOCHE» o «(VIGILANTE)», o son
# /guardar, /clear y /retomar. Si escribió en los últimos 3 min, no se le
# teclea encima. Eran 15 hasta el 27-10-2026: una pregunta suya («cómo va»)
# paraba la cola un cuarto de hora, y la sesión, al contestarle, se quedaba quieta.
usuario_activo() {
  local f; f=$(viva)
  [ -n "$f" ] || return 1
  tail -400 "$f" | python3 -c '
import sys, json, datetime as dt
ult = None
for l in sys.stdin:
    try: d = json.loads(l)
    except Exception: continue
    # isMeta: el texto expandido de un /mandato, no algo que él escribió.
    if d.get("type") != "user" or d.get("isMeta"): continue
    c = d.get("message", {}).get("content")
    if isinstance(c, list):
        c = " ".join(x.get("text", "") for x in c if isinstance(x, dict) and x.get("type") == "text")
    if not isinstance(c, str) or not c.strip() or "MODO NOCHE" in c or "(VIGILANTE)" in c: continue
    if c.lstrip().startswith("<command-message>"):
        # Un /mandato. Los que teclean el vigilante y `proyecto --seguir` no cuentan.
        if any(f"<command-name>/{x}</command-name>" in c for x in ("guardar", "clear", "retomar", "trabajar", "mandatos", "noche", "modonoche", "mododia")):
            continue
    elif c.lstrip().startswith("<"):
        continue   # avisos del sistema (tareas de fondo, salidas de órdenes), no él
    ult = d.get("timestamp")
if not ult: sys.exit(1)
t = dt.datetime.fromisoformat(ult.replace("Z", "+00:00"))
sys.exit(0 if (dt.datetime.now(dt.timezone.utc) - t).total_seconds() < int(sys.argv[1]) else 1)' "${1:-180}"
}

# ¿Su ultimo mensaje termina en pregunta? Entonces hay que darle al usuario
# tiempo de contestar antes de escribirle /trabajar encima.
ultima_es_pregunta() {
  local f; f=$(viva) || return 1
  tail -300 "$f" | python3 -c '
import sys, json
ult = ""
for l in sys.stdin:
    try: d = json.loads(l)
    except Exception: continue
    if d.get("type") != "assistant": continue
    for x in d.get("message", {}).get("content") or []:
        if isinstance(x, dict) and x.get("type") == "text" and x["text"].strip():
            ult = x["text"].strip()
sys.exit(0 if ult.rstrip("*_` ").endswith("?") else 1)'
}

# Segundos desde lo último que se escribió en la conversación viva.
callada() {
  local f; f=$(viva)
  [ -n "$f" ] || { echo 0; return; }
  echo $(( $(date +%s) - $(stat -c %Y "$f") ))
}

# ¿Se compactó la conversación? Claude Code lo hace solo si el contexto se llena
# A MITAD de una tarea. Después el contexto baja del umbral, pero se sigue sobre
# un resumen: al terminar esa tarea se recicla igual, para empezar limpia.
compactada() {
  local f; f=$(viva)
  [ -n "$f" ] && grep -q '"compact_boundary"' "$f"
}

# ¿Está esperando algo en segundo plano? La sesión termina el turno con «espero a
# que termine la sonda» y la pantalla queda igual que parada: el 26-10-2026 el
# vigilante le escribió /trabajar dos veces encima de un subagente y una sonda.
#   · lo de Claude: lo lanzado en segundo plano (órdenes y subagentes) cuyo
#     aviso de fin (<task-notification>) aún no llegó;
#   · un `encargar --fondo`: su fichero «vivo» con el proceso aún corriendo.
en_espera() { encargos_vivos || en_sesion; }
encargos_vivos() {
  local V PID   # uno por encargo corriendo (encargar, desde el 27-10-2026)
  for V in ~/.local/state/encargos/vivos/* ~/.local/state/encargos/vivo; do
    [ -f "$V" ] || continue
    PID=$(sed -n 's/^PID=//p' "$V" | tr -d "'\"" | head -1)
    [ -n "$PID" ] && kill -0 "$PID" 2>/dev/null && return 0
  done
  return 1
}
# Lo que vive DENTRO de la sesion. `en_sesion agentes`: solo los subagentes, que
# son lo unico que se pierde con /clear. Las ORDENES de fondo NO mueren: el
# 7-11-2026 las de una cola de pruebas (21:23, 21:49, 22:11)
# seguian vivas tras el /clear de las 22:32, y la sesion nueva las seguia
# viendo. Esperarlas antes de reciclar solo retrasaba el reciclaje (de 150.000 a
# 215.000 tokens con una cola que nunca se vacia). Sin argumento, las dos cosas:
# para decidir si esta esperando algo y no hay que escribirle /trabajar.
en_sesion() {
  local f; f=$(viva)
  [ -n "$f" ] || return 1
  # Una ORDEN en segundo plano cuenta como espera solo 20 min: el 27-10-2026 la
  # sesion dejo corriendo la app de Streamlit para inspeccionar el front, que no
  # acaba nunca, y el vigilante se quedo esperandola. Una suite tarda ~2 min.
  # Los subagentes se esperan siempre (hasta el tope de 90 min de abajo).
  tail -3000 "$f" | python3 -c '
import sys, re, json, time
from datetime import datetime
ordenes, agentes, acabadas = {}, set(), set()
esperas = set()   # las de `encargar`: esperan a un encargo, que sobrevive al /clear; no se esperan
for l in sys.stdin:
    try: d = json.loads(l); t = datetime.fromisoformat(d.get("timestamp", "").replace("Z", "+00:00")).timestamp()
    except Exception: d, t = {}, time.time()
    for x in (d.get("message") or {}).get("content") or []:
        if isinstance(x, dict) and x.get("type") == "tool_use" and re.search(r"\bencargar\b", str(x.get("input", {}).get("command", ""))):
            esperas.add(x.get("id"))
    if any(e and e in l for e in esperas) and "tool_result" in l: continue
    for i in re.findall(r"running in background with ID: (\w+)", l) + re.findall(r"moved to the background \(ID: (\w+)\)", l):
        ordenes.setdefault(i, t)
    agentes.update(re.findall(r"agentId: (\w+)", l))
    acabadas.update(re.findall(r"<task-id>(\w+)</task-id>", l))
vivas = [i for i, t in ordenes.items() if i not in acabadas and time.time() - t < 1200]
solo_agentes = sys.argv[1:] == ["agentes"]
sys.exit(0 if (agentes - acabadas) or (vivas and not solo_agentes) else 1)' "$@"
}

# Lo que ya volvio mientras espera a otro (27-10-2026): la sesion se quedo
# 10 min parada con dos encargos terminados, esperando al tercero, y el
# vigilante no le escribia porque «algo sigue en segundo plano». Ahora, si
# vuelve un encargo y la sesion lleva 5 min parada, se le dice cual.
HISTORIAL=~/.local/state/encargos/historial.tsv
vueltos() { [ -f "$HISTORIAL" ] && wc -l < "$HISTORIAL" || echo 0; }
# Los que la sesion ya vio: `encargar` sin --fondo espera a su encargo y, al
# volver, Claude Code la despierta. De esos no se avisa: el aviso es de respaldo,
# para los --fondo que nadie esperaba.
AVISADOS=~/.local/state/encargos/avisados
avisados() { [ -f "$AVISADOS" ] && wc -l < "$AVISADOS" || echo 0; }

pendientes() { local n; n=$(grep -cE '^\|[^|]*\| *(⬜|🔄)' ~/"$REPO"/.proyecto/tareas.md 2>/dev/null); echo "${n:-0}"; }
cabeza() { git -C ~/"$REPO" log --all -1 --format=%H 2>/dev/null; }

terminar() {
  log "🏁 $1 → /guardar y fin"
  esperar 60; teclear "/guardar"; esperar 60
  rm -f "$MARCA"; exit 0
}

log "▶ encendido en $REPO, modo $MODO (reciclar a ${UMBRAL} tokens)"
DESDE=$(date +%s); ULTIMA=$(cabeza); VISTOS=$(vueltos); AVISTOS=$(avisados)
EMPUJES=0; EMPUJE_T=0; EMPUJE_CABEZA=""

while [ -f "$MARCA" ]; do
  if ! tmux has-session -t "=$REPO" 2>/dev/null; then log "✗ la sesión de trabajo ya no existe"; rm -f "$MARCA"; exit 1; fi

  if [ "$MODO" = dia ]; then
    C=$(contexto)
    # Sin escribirle nada en el chat (usuario, 7-11-2026: «antes hacia guardar
    # clear retomar muy cercano a los 15% y sin escribir nada en el chat»). Hubo
    # un dia un mensaje «(VIGILANTE)» pidiendole que cerrara: sobraba, lo que
    # retrasaba era esperar a sus ordenes de fondo (ver en_sesion).
    if ! ocupada && ! dialogo && ! en_cola && ! usuario_activo 1200 && ! en_sesion agentes \
       && { [ "$C" -ge "$UMBRAL" ] || compactada; }; then
      log "♻ (día) contexto en $C tokens y 20 min sin mensajes tuyos: /guardar, /clear, /retomar, /trabajar"
      teclear "/guardar"; esperar 60
      teclear "/clear";   esperar 5
      teclear "/retomar"; esperar 30
      # Y SIGUE (5-11-2026): sin esto, tras retomar se quedaba parada con los
      # huecos vacios hasta que el usuario volviera. Lo que necesite al usuario
      # va con `preguntar` y pasa a otra tarea (CLAUDE.md, regla 9).
      teclear "/trabajar"; esperar 120
    # PARADA SIN LLEGAR AL UMBRAL (7-11-2026). Con el contexto bajo, nadie la
    # movia: tras reiniciar la maquina se quedo 1 h 34 quieta con 136.000 tokens y la
    # cola llena. Si lleva 20 min parada, sin mensajes tuyos y sin nada en
    # segundo plano, /trabajar. Los 20 min se miden desde que ella callo, para
    # no pasar por encima de una pregunta que acaba de hacerte. Si no avanza,
    # cada vez espera mas (1 h, 2 h) y a la tercera lo deja hasta el proximo
    # commit: lo que le quede puede ser solo lo que necesita de ti.
    # SIN PREGUNTA, 5 MIN (11-11-2026). Esperar 20 min tras CADA tarea era
    # demasiado: una sesion cerraba con «Lo siguiente es X. ¿Sigo?» y se quedaba
    # quieta 20 min por tarea. Si su ultimo mensaje no termina en «?», no hay
    # pregunta que respetar: 5 min. Si termina en «?», 20, como siempre.
    elif ESPERA=$( ultima_es_pregunta && echo 1200 || echo 300 ) \
         && ! ocupada && ! dialogo && ! en_cola && ! usuario_activo "$ESPERA" && ! en_espera \
         && [ "$(callada)" -ge "$ESPERA" ] && [ "$(pendientes)" != 0 ] \
         && ! pantalla | grep -qiE 'usage limit|limit reached|rate limit|resets at'; then
      AHORA=$(cabeza)
      [ "$AHORA" = "$EMPUJE_CABEZA" ] || EMPUJES=0
      if [ "$EMPUJES" -lt 3 ] && [ $(( $(date +%s) - EMPUJE_T )) -ge $(( EMPUJES * 3600 )) ]; then
        EMPUJES=$(( EMPUJES + 1 )); EMPUJE_T=$(date +%s); EMPUJE_CABEZA=$AHORA
        log "→ (día) 20 min parada con $(pendientes) pendientes y contexto $C: /trabajar ($EMPUJES de 3 sin avance)"
        teclear "/trabajar"; esperar 120
      fi
    fi
    sleep 60; continue
  fi

  if dialogo; then tmux send-keys -t "=$REPO:" Escape; log "diálogo cerrado con Esc"
  elif pantalla | grep -qiE 'usage limit|limit reached|rate limit|resets at'; then
    log "⏸ límite de uso: espero 20 min"; sleep 1200; continue
  elif ! ocupada; then
    if usuario_activo || en_cola; then
      [ "${AVISADO:-0}" = 1 ] || log "⏸ el usuario está escribiendo: no tecleo mientras siga (3 min sin mensajes suyos)"
      AVISADO=1; sleep "$PAUSA"; continue
    fi
    AVISADO=0
    # CONTEXTO LLENO Y SOLO ENCARGOS CORRIENDO: se recicla ya, sin esperarlos
    # (27-10-2026). Siguen corriendo y la sesion limpia los recoge al retomar.
    # Lo que vive dentro de la sesion si se espera: se perderia con /clear.
    C=$(contexto)
    if { [ "$C" -ge "$UMBRAL" ] || compactada; } && ! en_sesion agentes; then
      encargos_vivos && log "♻ contexto en $C tokens con encargos corriendo: no los espero (siguen solos)"
      ESPERANDO=0
    elif en_espera && [ "${ESPERANDO:-0}" -lt 180 ]; then
      [ "${ESPERANDO:-0}" = 0 ] && log "⏳ espera algo en segundo plano: no tecleo hasta que acabe"
      ESPERANDO=$(( ${ESPERANDO:-0} + 1 ))
      N=$(vueltos)
      if [ $(( N - VISTOS )) -gt $(( $(avisados) - AVISTOS )) ] && [ $(( ESPERANDO * PAUSA )) -ge 120 ]; then
        Q=$(tail -n $(( N - VISTOS )) "$HISTORIAL" | cut -f4 | sed -n 's/.*# Encargo \([^—]*\)—.*/\1/p' | sed 's/ *$//' | paste -sd',' | sed 's/,/, /g')
        log "↩ ya volvieron $(( N - VISTOS )) encargos mientras espera: se lo digo"
        teclear "(MODO NOCHE) Ya volvieron: $Q. Ciérralos ahora, sin esperar a los que siguen corriendo (encargar --estado / --leer <ID>), y rellena su hueco. Si ya lo cerraste, sigue."
        VISTOS=$N; AVISTOS=$(avisados); ESPERANDO=0; esperar 120; continue
      fi
      sleep "$PAUSA"; continue
    fi
    [ "${ESPERANDO:-0}" -ge 180 ] && log "⚠ 90 min esperando algo en segundo plano: le escribo igual"
    ESPERANDO=0; VISTOS=$(vueltos); AVISTOS=$(avisados)
    [ "$(pendientes)" = 0 ] && terminar "no quedan tareas pendientes"
    # ATASCO = TIEMPO SIN COMMITS, NO RONDAS (29-10-2026). Antes eran 3 rondas
    # sin commit, y una ronda dura lo que tarda la sesion en contestar «espero
    # al usuario» (~2 min): el 29-10 a las 11:37 se apago sola en 8 minutos
    # mientras la sesion esperaba una corrida de 35 min en DEV, y no volvio a
    # encenderse en todo el dia. Ahora: con encargos corriendo no cuenta; sin
    # commits en 60 min se aparta 30 min y vuelve a probar; solo se apaga tras
    # 3 h sin ningun commit.
    AHORA=$(cabeza)
    if [ "$AHORA" != "$ULTIMA" ] || encargos_vivos; then ULTIMA=$AHORA; DESDE=$(date +%s); fi
    QUIETA=$(( ( $(date +%s) - ${DESDE:-$(date +%s)} ) / 60 ))
    [ "$QUIETA" -ge 180 ] && terminar "3 h sin commits ni encargos: atascada"
    if [ "$QUIETA" -ge 60 ] && [ "$(( $(date +%s) - ${APARTADA:-0} ))" -ge 3600 ]; then
      log "😴 $QUIETA min sin commits ni encargos: no tecleo en 30 min (se apaga a las 3 h)"
      APARTADA=$(date +%s); sleep 1800; continue
    fi
    C=$(contexto)
    # NO SE RECICLA CON EL USUARIO EN LA CONVERSACION (30-10-2026). Para
    # /trabajar basta con que no haya escrito en 3 min; para /clear no: se lleva
    # la conversacion en la que esta. El 30-10 a las 15:41 recicló mientras el
    # usuario redactaba un mensaje largo desde el movil, y lo que se escribe en
    # Remote Control no se ve hasta que se envia. Ahora espera 20 min sin
    # mensajes suyos; mientras, si el contexto se llena, Claude Code compacta.
    if { [ "$C" -ge "$UMBRAL" ] || compactada; } && { usuario_activo 1200 || en_cola; }; then
      [ "${AVISO_RECICLAR:-0}" = 1 ] || log "♻ contexto en $C tokens, pero el usuario escribió hace menos de 20 min: no reciclo todavía"
      AVISO_RECICLAR=1
    elif [ "$C" -ge "$UMBRAL" ] || compactada; then
      AVISO_RECICLAR=0
      log "♻ contexto en $C tokens$(compactada && echo ', compactada'): /guardar, /clear, /retomar"
      teclear "/guardar"; esperar 60
      teclear "/clear";   esperar 5
      teclear "/retomar"; esperar 30
    fi
    log "→ /trabajar ($(pendientes) pendientes, contexto $C)"
    # Con el recordatorio: una sesión abierta antes de que existiera la sección
    # «Modo noche» de CLAUDE.md no la tiene cargada.
    teclear "/trabajar (MODO NOCHE: el usuario duerme. Sigue la sección «Modo noche» de CLAUDE.md: no preguntes, marca ⛔ lo que necesite al usuario y pasa a otra; nada irreversible.)"; esperar 120
  fi
  sleep "$PAUSA"
done
log "■ apagado"

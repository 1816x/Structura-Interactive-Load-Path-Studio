#!/bin/bash
# Levanta el bloqueo que impide al conductor teclear codigo del producto.
#
# POR QUE EXISTE: la regla «el conductor no teclea» solo funciona si no tiene
# excepciones — en cuanto las tiene, vuelve a ser un consejo. Pero hay casos
# reales donde teclear aqui es lo correcto:
#
#   - Codex ya fallo dos veces con el mismo encargo
#   - Codex no responde, o se agoto la cuota del plan
#   - un arreglo de una linea que ya sabes exactamente cual es
#
# Asi que la excepcion existe, pero hay que PEDIRLA. Deja rastro: el fichero
# `.proyecto/editar-yo` queda ahi hasta que se quita, y `/guardar` lo mira.
#
#   tocar-yo         permitir edicion directa (y decir como esta ahora)
#   tocar-yo --fin   volver a bloquear
set -euo pipefail

case "${1:-}" in
  -h|--help|ayuda|--ayuda)
    sed -n '2,18p' "$0" | sed -n '/^#/p' | sed 's/^# \?//'
    exit 0 ;;
esac

RAIZ="$(git rev-parse --show-toplevel 2>/dev/null)" || {
  echo "✗ esto se usa dentro del repositorio de un proyecto"; exit 1; }
MARCA="$RAIZ/.proyecto/editar-yo"

if [ "${1:-}" = "--fin" ]; then
  rm -f "$MARCA"
  echo "✓ vuelve a bloquearse. El codigo del producto se encarga con: encargar"
  exit 0
fi

mkdir -p "$(dirname "$MARCA")"
{ echo "# Puesto el $(date '+%Y-%m-%d %H:%M') con \`tocar-yo\`."
  echo "# Mientras exista, el conductor puede editar ficheros del producto."
  echo "# Quitarlo con: tocar-yo --fin"
} > "$MARCA"

echo "✓ edicion directa PERMITIDA en $(basename "$RAIZ")"
echo
echo "  Se ha desactivado la regla que manda el codigo a Codex. Es a proposito"
echo "  y esta bien, pero no se te olvide cerrarla:"
echo "     tocar-yo --fin"
echo
echo "  (queda anotado en .proyecto/editar-yo; /guardar avisa si sigue puesto)"

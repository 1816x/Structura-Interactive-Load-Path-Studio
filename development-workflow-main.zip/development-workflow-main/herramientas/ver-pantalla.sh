#!/bin/bash
# Abre una pagina de verdad y saca lo que hace falta para juzgarla.
#
# EL HUECO QUE CERRABA: los dos verificadores de interfaz revisaban el CODIGO
# de la pantalla y deducian como se veria. Entre «el codigo parece correcto» y
# «asi se ve en el navegador» cabe casi todo el trabajo de front-end.
#
# POR QUE NO SOLO UNA CAPTURA: una imagen no dice que elemento tiene mal el
# z-index, ni que rol ARIA falta, ni de que color exacto es un texto. Saca
# pixeles Y estructura, que es lo que permite MEDIR en vez de opinar.
#
# Deja tres ficheros en .proyecto/pantallas/:
#   <nombre>.png          la captura, pagina entera
#   <nombre>.html         el DOM ya renderizado (no el fuente)
#   <nombre>.txt          arbol de accesibilidad + colores y tamaños usados
#
# Uso:  ver-pantalla <url> [--ancho N] [--nombre X] [--esperar SEG]
#       ver-pantalla --estado     que falta para poder ver
#       ver-pantalla --instalar   deja el navegador listo (baja ~150 MB)
#
#   --ancho N     ancho de ventana. 360 para movil, por defecto 1280
#   --esperar S   segundos extra tras cargar, para apps que pintan despues
#
# EQUIVALENTE MANUAL:  npx playwright screenshot <url> salida.png
set -euo pipefail

SALIDA=".proyecto/pantallas"

# Los modulos globales de npm NO estan en la ruta de busqueda de node. Sin esto
# `require("playwright")` falla aunque este instalado, y el mensaje no lo dice.
command -v npm >/dev/null && export NODE_PATH="$(npm root -g 2>/dev/null)"

estado() {
  echo "▸ estado del visor"
  command -v node >/dev/null && echo "  ✓ node $(node --version)" || echo "  ✗ falta node"
  node -e "require('playwright')" 2>/dev/null && echo "  ✓ playwright instalado" \
    || echo "  ✗ falta playwright (ver-pantalla --instalar)"
  [ -x /opt/google/chrome/chrome ] && echo "  ✓ Chrome instalado (lo usa el navegador del agente)" \
    || echo "  ✗ falta Chrome — los verificadores no podran abrir nada (ver-pantalla --instalar)"
}

instalar() {
  command -v npm >/dev/null || { echo "✗ no hay npm en esta maquina"; exit 1; }
  echo "▸ instalando playwright (~1 min)"
  sudo npm install -g playwright >/dev/null 2>&1 || npm install --no-save playwright >/dev/null 2>&1
  export NODE_PATH="$(npm root -g 2>/dev/null)"
  # OJO: el MCP del navegador pide CHROME, no el chromium que trae playwright.
  # Se comprobo: con solo chromium falla con «Chromium distribution chrome is
  # not found at /opt/google/chrome/chrome». Son ~400 MB, y por eso esto no se
  # instala en toda VM: solo donde haya web que mirar.
  echo "▸ instalando Chrome (~400 MB, una sola vez; lo necesita el navegador del agente)"
  sudo npx playwright install chrome 2>&1 | tail -2
  estado
}

case "${1:-}" in
  -h|--help|ayuda|--ayuda|"")
    sed -n '2,25p' "$0" | sed -n '/^#/p' | sed 's/^# \?//'; exit 0 ;;
  --estado)   estado; exit 0 ;;
  --instalar) instalar; exit 0 ;;
esac

URL="$1"; shift
ANCHO=1280; NOMBRE=""; ESPERAR=1
while [ $# -gt 0 ]; do
  case "$1" in
    --ancho)   ANCHO="${2:-1280}"; shift 2 ;;
    --nombre)  NOMBRE="${2:-}"; shift 2 ;;
    --esperar) ESPERAR="${2:-1}"; shift 2 ;;
    *) echo "✗ opcion desconocida: $1"; exit 1 ;;
  esac
done
[ -z "$NOMBRE" ] && NOMBRE="$(printf '%s' "$URL" | tr -cs 'a-zA-Z0-9' '-' | sed 's/^-//; s/-$//')-${ANCHO}"

node -e "require('playwright')" 2>/dev/null || {
  echo "✗ falta el navegador. Instalalo una vez con:  ver-pantalla --instalar"; exit 1; }

# Comprobar que hay algo sirviendo ANTES de abrir el navegador: si no, el error
# de playwright es largo y no dice lo obvio, que es «no has levantado la app».
if ! curl -s -o /dev/null -m 5 "$URL"; then
  echo "✗ nadie contesta en $URL"
  echo "  ¿esta levantada la aplicacion? (npm run dev, o lo que use este proyecto)"
  exit 1
fi

mkdir -p "$SALIDA"
URL="$URL" ANCHO="$ANCHO" NOMBRE="$NOMBRE" SALIDA="$SALIDA" ESPERAR="$ESPERAR" node -e '
const { chromium } = require("playwright");
const fs = require("fs");
(async () => {
  // channel "chrome": el Chrome de /opt/google/chrome, el mismo que usa el
  // navegador de los agentes. Sin esto Playwright busca SU chromium en
  // ~/.cache/ms-playwright, que --instalar no baja: en un proyecto falló con
  // «Executable does not exist … chrome-headless-shell» (26-10-2026).
  const nav = await chromium.launch({ channel: "chrome" });
  const pag = await nav.newPage({ viewport: { width: +process.env.ANCHO, height: 900 } });
  await pag.goto(process.env.URL, { waitUntil: "networkidle", timeout: 30000 });
  await pag.waitForTimeout(+process.env.ESPERAR * 1000);

  const base = process.env.SALIDA + "/" + process.env.NOMBRE;
  await pag.screenshot({ path: base + ".png", fullPage: true });
  fs.writeFileSync(base + ".html", await pag.content());

  // Lo que permite MEDIR en vez de opinar: que colores y tamaños se usan de
  // verdad, y si algo se sale por el ancho.
  const datos = await pag.evaluate(() => {
    const colores = new Map(), fuentes = new Map(), espacios = new Map();
    let desbordan = [];
    for (const el of document.querySelectorAll("*")) {
      const s = getComputedStyle(el);
      if (el.textContent && el.textContent.trim()) {
        colores.set(s.color, (colores.get(s.color) || 0) + 1);
        fuentes.set(s.fontSize + " / " + s.fontWeight, (fuentes.get(s.fontSize + " / " + s.fontWeight) || 0) + 1);
      }
      if (s.backgroundColor && s.backgroundColor !== "rgba(0, 0, 0, 0)")
        colores.set(s.backgroundColor, (colores.get(s.backgroundColor) || 0) + 1);
      for (const p of [s.paddingTop, s.paddingLeft, s.marginTop, s.gap])
        if (p && p !== "0px" && p !== "normal") espacios.set(p, (espacios.get(p) || 0) + 1);
      const r = el.getBoundingClientRect();
      if (r.width > 0 && r.right > document.documentElement.clientWidth + 1)
        desbordan.push(el.tagName.toLowerCase() + (el.className && typeof el.className === "string" ? "." + el.className.split(" ")[0] : "") + "  se sale " + Math.round(r.right - document.documentElement.clientWidth) + "px");
    }
    const orden = m => [...m.entries()].sort((a, b) => b[1] - a[1]).map(([k, v]) => "  " + k + "   (" + v + " veces)");
    return {
      titulo: document.title,
      scrollHorizontal: document.documentElement.scrollWidth > document.documentElement.clientWidth,
      colores: orden(colores), fuentes: orden(fuentes), espacios: orden(espacios),
      desbordan: [...new Set(desbordan)].slice(0, 15),
    };
  });

  // page.accessibility.snapshot() se RETIRO en playwright 1.5x. Su sustituto
  // es ariaSnapshot(), que ademas devuelve algo mas legible (YAML, no JSON).
  let a11y = "(no disponible en esta version de playwright)";
  try { a11y = await pag.locator("body").ariaSnapshot(); }
  catch (e) { a11y = "(no se pudo sacar: " + e.message + ")"; }
  const txt = [
    "URL: " + process.env.URL,
    "Ancho: " + process.env.ANCHO + "px   ·   Titulo: " + datos.titulo,
    "Scroll horizontal: " + (datos.scrollHorizontal ? "SI — algo se sale" : "no"),
    "",
    "=== ELEMENTOS QUE SE SALEN (" + datos.desbordan.length + ") ===",
    ...(datos.desbordan.length ? datos.desbordan : ["  ninguno"]),
    "",
    "=== COLORES USADOS (" + datos.colores.length + " distintos) ===", ...datos.colores.slice(0, 20),
    "",
    "=== TAMAÑOS DE TEXTO (" + datos.fuentes.length + " distintos) ===", ...datos.fuentes.slice(0, 15),
    "",
    "=== ESPACIADOS (" + datos.espacios.length + " distintos) ===", ...datos.espacios.slice(0, 20),
    "",
    "=== ARBOL DE ACCESIBILIDAD ===",
    a11y,
  ].join("\n");
  fs.writeFileSync(base + ".txt", txt);
  await nav.close();

  console.log("✓ " + base + ".png   la captura, pagina entera");
  console.log("✓ " + base + ".html  el DOM renderizado");
  console.log("✓ " + base + ".txt   medidas y accesibilidad");
  console.log("");
  console.log("  colores distintos: " + datos.colores.length + "  ·  tamaños de texto: " + datos.fuentes.length + "  ·  espaciados: " + datos.espacios.length);
  if (datos.scrollHorizontal) console.log("  ⚠ HAY SCROLL HORIZONTAL: " + datos.desbordan.length + " elementos se salen");
})();
'

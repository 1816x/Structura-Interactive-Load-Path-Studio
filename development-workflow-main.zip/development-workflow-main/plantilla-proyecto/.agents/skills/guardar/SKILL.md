---
name: guardar
description: Me voy — deja todo apuntado para retomarlo sin perder nada
---

<!-- Generado de .claude/commands/guardar.md por generar-codex.py: mismo mandato, para Codex. Invocalo con $guardar o /skills. NO editar aqui: se pisa. -->

Cierra la sesion. Objetivo: que la proxima, **sin nada de este contexto**,
arranque sin perder un minuto.

## 1. Primero, que no quede nada sin commitear

`git status`. Si hay cambios sueltos, o se commitean o se explica por que no.
Un traspaso que apunta a ficheros sin guardar no sirve de nada.

Sella el estado en la cabecera de `tareas.md`:

```
estado_escrito_contra: <git rev-parse --short HEAD>
```

## 1-bis. ¿Quedo abierta la salida de emergencia?

Si existe `.proyecto/editar-yo`, alguien uso `tocar-yo` para poder teclear
codigo del producto y no lo cerro. **Cierralo**: `tocar-yo --fin`.

Y anotalo en el diario: por que hizo falta. Si pasa a menudo, el problema no es
la regla — es que los encargos van vagos.

## 2. Lo que quedo a medias

Si hay una tarea 🔄, anota debajo en `tareas.md` **exactamente** donde quedo:
que ficheros estan tocados, que funciona ya, que falta. Si quedo inservible,
dilo — mejor que el proximo lo tire y rehaga a que lo descubra depurando.

## 3. El traspaso: `.proyecto/retomar-aqui.md`

Escribelo **solo si queda trabajo a medias**. Si la sesion cierra limpia, no lo
crees: un traspaso vacio es ruido.

```markdown
# Retomar aquí

**Escrito:** <AAAA-MM-DD HH:MM> · contra <SHA corto>

## Dónde me quedé
<una frase: la última acción completada>

## Lo siguiente, concreto
<la primera acción de la próxima sesión. No «seguir con X»: qué se abre y qué
se escribe. Tiene que ser algo que la próxima sesión pueda EMPEZAR SOLA:
«preguntar al dueño si ya hizo X» no vale — eso va en *Necesito del usuario*.
Si todo lo pendiente depende del dueño, dilo, y nombra qué se hace mientras
tanto sacándolo de las tareas sueltas.>

## NO REPITAS ESTO
<lo que ya se probó y falló EN ESTA TAREA, con por qué. Vacío si no hubo.>

- **[bloquea]** <esto hace perder la sesión entera si se reintenta>
- **[aviso]** <esto cuesta un rato, pero se sale>

## Lo que está a medias en disco
<ficheros tocados y en qué estado: compila / no compila / a medias>

## Caduca
<hechos que dejan de ser verdad solos: respaldos con hora, conteos de una
guardia que aborta si entran filas nuevas, credenciales, ficheros que solo
existen en esta máquina. Di qué los invalida y qué hay que rehacer.
QUITA LA SECCIÓN ENTERA si no hay nada — una sección que se rellena por
ritual es peor que no tenerla.>

## Necesito del usuario
<decisiones o accesos que bloquean. «Nada» si no hay.
Cada punto lleva CÓMO SABER SI YA ESTÁ HECHO: un comando si lo hay, o las
palabras «solo lo sabe el dueño» si de verdad no hay forma de comprobarlo.
Así la próxima sesión llega con respuestas, no con preguntas.>
```

**NO REPITAS ESTO es la seccion que mas se agradece.** No es contexto: es un
error ya pagado. Sin ella, la proxima sesion vuelve a intentar lo mismo y
descubre lo mismo, gastando lo que ya se gasto.

> [!important] Este fichero es de un solo uso
> `/retomar` lo lee y **lo borra**. Un traspaso que sobrevive a su motivo
> ensucia las sesiones siguientes con cosas ya resueltas, y peor: hace dudar de
> si de verdad se hicieron. Lo que deba durar va al diario, no aqui.

## 4. Entrada de cierre en `.proyecto/diario.md`

```markdown
## <AAAA-MM-DD> — Cierre

**Avancé:** <tareas terminadas hoy>
**A medias:** <estado exacto, o «nada»>
**Descubrí:** <lo que cambia el plan>
**No funcionó:** <lo intentado que falló>
**Se retoma por:** <la primera acción concreta de la próxima vez>
```

## 5. Corrige lo que quedo desfasado

- ¿Algo de hoy contradice `como-lo-hacemos.md`? Corrigelo alli, con su
  **Porque** y su **Descartamos**. Un diseno que miente es peor que ninguno.
- ¿Cambio el alcance? Toca `que-hacemos.md`.
- ¿Salieron tareas nuevas? A `tareas.md`, no a la memoria de nadie.

## 6. Commit final y empujar la rama

Todo lo de `.proyecto/` en un commit, y `git push -u origin HEAD`. El
repositorio es lo unico que sobrevive a la sesion.

**No fusiones a `main`.** Deja la rama subida y di al usuario que, cuando quiera
subirla a `main`, la fusione él (un pull request de `staging` a `main`, o
`git merge` desde su máquina). La decisión es suya.

Si la rama quedo a medias y no compila, **dilo en el resumen**: mejor que se
quede sin fusionar a que entre rota.

## 7. Cuatro lineas

Que se hizo · que quedo a medias · por donde se retoma · que hace falta del
usuario.

Recuerdale que la proxima vez empieza con `/retomar`.

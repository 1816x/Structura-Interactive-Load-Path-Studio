---
name: modonoche
description: Modo noche — sigue trabajando sola mientras el usuario duerme (/modonoche · /modonoche parar · /modonoche ver)
---

<!-- Generado de .claude/commands/modonoche.md por generar-codex.py: mismo mandato, para Codex. Invocalo con $modonoche o /skills. NO editar aqui: se pisa. -->

El usuario pide el modo noche: **$ARGUMENTS**

Un vigilante (`noche`, en su propia ventana tmux) te escribirá `/trabajar` cada
vez que te pares, y `/guardar` + `/clear` + `/retomar` cuando se te llene el
contexto, hasta que él lo apague. Ver la sección «Modo noche» de `CLAUDE.md`:
de noche **no preguntas**, marcas ⛔ y sigues con otra.

Solo hay **un** vigilante: encender el modo noche apaga el modo día.

Según lo que haya pedido, corre **una** de estas órdenes con Bash, desde la
carpeta del repo:

| Pidió | Orden |
|---|---|
| nada (encender) | `noche --ver` primero; luego `noche "$(basename "$PWD")"` |
| `parar`, `apagar`, `quitar` | `noche --parar` |
| `ver`, `cómo va` | `noche --ver` |

Después:

- **Al encenderlo:** dile en dos líneas que sigue hasta que lo apague con
  `/modonoche parar`, que lo que hizo lo ve con `/modonoche ver`, y que si sigue
  despierto puede seguir hablándote (el vigilante no teclea mientras él haya
  escrito hace poco). Si estaba puesto el modo día, dile que lo cambiaste.
  **Termina el turno ahí**: el vigilante te mandará `/trabajar` en un par de
  minutos.
- **Al pararlo:** confírmalo en una línea.
- **Al verlo:** resume el registro. Primero lo que necesita de él (las tareas
  ⛔ y sus preguntas), luego lo hecho, sin copiar el registro entero.

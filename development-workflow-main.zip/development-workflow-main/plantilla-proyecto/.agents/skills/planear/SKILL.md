---
name: planear
description: Decidir qué construimos, cómo, y partirlo en tareas
---

<!-- Generado de .claude/commands/planear.md por generar-codex.py: mismo mandato, para Codex. Invocalo con $planear o /skills. NO editar aqui: se pisa. -->

Vas a dejar el proyecto listo para empezar. Idea: **$ARGUMENTS**

Son tres pasos. **Para despues de cada uno**, ensena lo escrito y espera
confirmacion antes de seguir. Si el usuario dice que ya hay parte hecha, lee lo
que exista en `.proyecto/` y salta a lo que falte.

---

## Quién hace qué

Tú (Fable) **planeas y juzgas**: decides qué se construye, cómo, en qué orden,
y qué es «terminado». **El código lo escribe Codex** vía `encargar` (modelo en
`.proyecto/ia.yaml`, clave `codex:`), y **lo revisa `senior-dev`** antes de
darlo por bueno. Los demás agentes (`disenador-interfaz`, `paranoico`,
`abogado-del-diablo`…) son consultores puntuales. Planea con eso en la cabeza:
cada tarea tiene que ser encargable en un texto de diez líneas con su
comprobación.

## Paso 1 — Qué construimos

Pregunta **de una en una**, maximo seis preguntas:

- ¿Quien lo usa y para hacer que? Alguien concreto haciendo algo concreto.
- ¿Como sabremos que funciona? Que tiene que pasar para darlo por bueno.
- ¿Que queda **fuera**? Sin esto el proyecto crece sin limite.
- ¿Que restricciones hay? Lenguaje, cosas que ya existen, plazos, lo intocable.
- ¿Que pasa si falla? Un juguete y algo de lo que dependes se construyen distinto.

Si una respuesta es vaga, repregunta. Lo vago aqui cuesta dias despues.

Escribe `.proyecto/que-hacemos.md`:

```markdown
# <nombre>

## Qué es
<dos frases en lenguaje llano>

## Para quién
<usuario y situación concreta>

## Estará terminado cuando
- [ ] <criterio observable y comprobable>

## Fuera de alcance
- <lo que NO se hace, y por qué>

## Restricciones
- <lenguaje, plataforma, plazos, lo que no se toca>

## Palabras que usamos
- **<término>**: <qué significa AQUÍ>
```

Ese ultimo apartado no es adorno: en la sesion 8 nadie recuerda si «trabajo»
era una fila de la base de datos o un proceso.

---

## Paso 2 — Cómo lo construimos

Si ya hay codigo, leelo antes: media decision ya esta tomada.

**Si el proyecto tiene interfaz**, una de esas decisiones es su sistema de
diseño: escribe `.proyecto/diseno.md`, el manual de la interfaz, con la
plantilla de la skill `pantallas` (para quién, sus tareas, el marco, cómo se
comporta todo, el vocabulario y el aspecto). Si el usuario nombra
una empresa con preset (p. ej. la de tu empresa), crea también `.proyecto/marca.yaml`.

Solo para las decisiones **caras de cambiar** (base de datos, forma de los
datos, limites entre piezas, autenticacion, despliegue). Lo demas es ruido.

Para cada una: **dos o tres opciones reales** con sus pegas de verdad, no de
folleto, y **recomienda una** diciendo por que. Espera respuesta.

Escribe `.proyecto/como-lo-hacemos.md`:

```markdown
# Cómo lo hacemos

## Forma general
<3-6 líneas: las piezas y cómo se hablan>

## Decisiones

### <título>
**Hacemos:** <qué>
**Porque:** <razón>
**Descartamos:** <alternativa> — <por qué no>
**Lo reabriríamos si:** <qué tendría que cambiar>

## Lo que puede salir mal
- <riesgo y cómo lo notaríamos>
```

**Descartamos** evita repetir el mismo debate cada tres sesiones.
**Lo reabriríamos si** evita lo contrario: quedarse atado a una decision cuyo
motivo ya no existe.

---

## Paso 3 — En qué tareas se parte

Cada tarea debe **caber en una sesion con contexto de sobra**. Lo que no cabe se
queda a medias, y lo que se queda a medias es lo que se pierde.

«Si dudas, partela» no sirve: siempre parece que cabe. Estos limites si se
pueden comprobar, y **no son consejo**:

| Señal | Que hacer |
|---|---|
| Toca mas de **5 ficheros** | partirla. Sin excepcion |
| Tiene mas de **3 subtareas** | partirla |
| No sabes escribir su comprobacion | no esta definida: definela antes |
| Cambia dos subsistemas a la vez | partirla por el limite entre ellos |

Cada tarea lleva un **verbo y un objeto** («añadir login con correo y
contraseña», no «autenticación»), una **comprobacion ejecutable**, y sus
dependencias.

Ordena para que **siempre haya algo funcionando**: mejor el camino entero pobre
que media casa perfecta.

Escribe `.proyecto/tareas.md`. **La cabecera lleva el sello de estado**: es lo
que permite a `/retomar` detectar solo que los apuntes se quedaron viejos, en
vez de depender de que alguien lo note.

```markdown
---
estado_escrito_contra: <git rev-parse --short HEAD>
---

# Tareas

⬜ pendiente · 🔄 en curso · ✅ hecha · ⛔ bloqueada · ❌ descartada

## Etapa 1 — <qué funciona al terminarla>

| # | | Tarea | Se comprueba con | Necesita |
|---|---|-------|------------------|----------|
| 1 | ⬜ | <verbo + objeto> | <mandato o prueba> | — |
```

No detalles mas alla de la etapa siguiente: lo que aprendas haciendo la primera
va a cambiar la segunda. Deja el resto en una linea suelta.

---

Haz commit de los tres ficheros.

Y antes de decir que ya se puede usar `/trabajar`, **asegurate de que existe
`staging`**, que es de donde saldra cada tarea y donde aterrizara:

```bash
git rev-parse --verify staging >/dev/null 2>&1 \
  || { git switch -c staging main && git push -u origin staging; }
```

POR QUE AQUI Y NO EN CADA TAREA: sin ese escalon, `/trabajar` no tiene donde
dejar el trabajo terminado, y cada rama acaba saliendo de la anterior — una
pila que da conflicto entera en cuanto se fusiona la primera. Paso el 29 de
agosto de 2026 con cinco tareas seguidas.

Ahora si: di que ya se puede usar `/trabajar`.

---
name: retomar
description: ¿Dónde me quedé? — recupera el estado, detecta lo desfasado y dice qué toca
---

<!-- Generado de .claude/commands/retomar.md por generar-codex.py: mismo mandato, para Codex. Invocalo con $retomar o /skills. NO editar aqui: se pisa. -->

Retomas este proyecto sin recordar nada de sesiones anteriores. Todo lo que
necesitas esta en ficheros.

## 0. El traspaso, si lo hay

¿Existe `.proyecto/retomar-aqui.md`? Leelo **antes que nada**. Ahi esta la
sesion pasada en fresco, incluida la seccion **NO REPITAS ESTO**.

Si trae entradas `[bloquea]`, **nombralas en voz alta** en tu informe antes de
proponer nada. Son errores ya pagados; reintentarlos gasta la sesion entera.

**Borralo cuando lo hayas leido y resumido.** Es de un solo uso: lo que deba
durar ya esta en el diario. Un traspaso que sobrevive a su motivo hace dudar de
si sus cosas se hicieron o no.

## 1. ¿Miente el estado? — esto se comprueba, no se opina

`tareas.md` lleva en su cabecera el SHA contra el que se escribio:

```
estado_escrito_contra: abc1234
```

Compara con `git rev-parse --short HEAD`.

| | |
|---|---|
| **Coinciden** | los apuntes estan al dia. Sigue |
| **Difieren, pero solo en `.proyecto/`** | es el commit de cierre, y esto pasa SIEMPRE: `guardar` sella en su paso 1 y commitea en el 6, asi que el sello apunta al commit de antes. Normal, sigue, y **no lo cuentes en el informe**. Compruebalo: `git log --oneline abc1234..HEAD -- . ':(exclude).proyecto'` — si sale vacio, ningun codigo se movio |
| **Difieren en codigo** | hay commits posteriores al ultimo apunte. **Miralos**: `git log --oneline abc1234..HEAD` |
| **No hay sello** | el proyecto es anterior a esto. Ponlo al cerrar y sigue |

Si hay commits **de codigo** sin anotar, **reconstruye la entrada del diario desde el diff**
antes de seguir trabajando. Un `git log` que cuenta cosas que el diario no
cuenta es contexto perdido, y se pierde entero en cuanto pasan dos sesiones.

## 2. ¿Esta el proyecto entero?

| Debe estar | Si falta |
|---|---|
| `.proyecto/que-hacemos.md` | nunca se corrio `/planear`. Ofrécelo |
| `.proyecto/como-lo-hacemos.md` | igual — sin esto se rediscute todo cada sesion |
| `.proyecto/tareas.md` | igual |
| `.proyecto/diario.md` | créalo vacío, no hace falta preguntar |
| `.proyecto/ia.yaml` | copia el de la plantilla, o dilo si no la tienes |
| `.claude/agents/` | sin verificadores no hay a quien pedir revision. Dilo |

**Ofrece, no impongas.** Si el usuario dice que el proyecto cabe en una tarde,
saltatelo: la ceremonia debe pagar lo que cuesta.

Comprueba que el motor local conteste, **una sola vez y sin insistir**:
`ia-local --lista`. Si contesta, no lo digas. Si no contesta no es grave — dilo en una linea y sigue. Lo
que no vale es descubrirlo a mitad de sesion.

## 3. Lee

1. `.proyecto/que-hacemos.md` — que es esto y que restricciones tiene
2. `.proyecto/como-lo-hacemos.md` — decisiones ya tomadas y por que
3. `.proyecto/tareas.md` — que esta hecho y que falta
4. `.proyecto/diario.md` — **las ultimas 3 entradas completas**; ahi estan los
   callejones sin salida ya explorados

   El diario se añade AL FINAL, asi que las tres primeras son las mas viejas —
   justo lo contrario de lo que buscas. Cortalo asi:

   ```bash
   sed -n "$(grep -n '^## ' .proyecto/diario.md | tail -3 | head -1 | cut -d: -f1),\$p" .proyecto/diario.md
   ```

Nada mas. **No abras el codigo todavia**: se abre cuando `/trabajar` diga cual,
y solo esa parte. Llenar el contexto aqui es empezar la sesion ya cansado.

## 4. Informa asi

**Que es esto** — dos frases.

**Donde va** — tareas hechas de cuantas.

**Ultimo movimiento** — que se hizo la vez pasada y como acabo.

**No repitas esto** — si el traspaso traia bloqueos, aqui, con todas las letras.

**Algo no cuadra** — **solo si de verdad hay algo**: commits de codigo sin
anotar, git dice una cosa y `tareas.md` otra, o falta algo de la tabla del
paso 2. El codigo manda; si discrepan, la documentacion esta vieja y se corrige
antes de seguir. **Si no hay nada, esta seccion no se escribe**: ni «nada», ni
el sello que difiere solo en `.proyecto/`, ni que el motor local contesta, ni
que borraste el traspaso. Al usuario le sonaba a problema cada vez.

**Lo siguiente** — que tarea toca y que necesitas del usuario para empezar.
Si `.proyecto/ia.yaml` tiene `a_la_vez:` de 2 o más, no es una tarea: son
**las que quepan** (`encargar --estado` lo dice). Dilo asi: «van 1 de 3 → lanzo
15i5 y 15i7». Y lo que dejo la sesion anterior, **antes** de lanzar
nada nuevo: los encargos que siguen corriendo son tuyos (atiendelos cuando
vuelvan), y cada worktree de `git worktree list` con una tarea 🔄 es trabajo a
medias: si su encargo ya volvio (`encargar --estado`, «ultimos encargos»),
revisalo y cierralo; si no hay encargo, mira su `git diff` y decide.

No programes nada. Esto solo recupera el estado. Si el usuario esta de acuerdo,
sigue con `/trabajar`.

---
name: revisar
description: ¿Los apuntes siguen siendo verdad? — los contrasta con el código
---

<!-- Generado de .claude/commands/revisar.md por generar-codex.py: mismo mandato, para Codex. Invocalo con $revisar o /skills. NO editar aqui: se pisa. -->

Todo esto se apoya en que `.proyecto/` diga la verdad. Cuando deja de decirla
es peor que no tener nada, porque te hace confiar en algo falso. Esto lo caza.

Pasalo cada pocas sesiones, o cuando algo «no cuadre».

## 1. El sello, primero

Compara `estado_escrito_contra` de `tareas.md` con `git rev-parse --short HEAD`.
Si difieren, `git log --oneline <sello>..HEAD` son los commits que nadie anoto.
Empieza por ahi: es lo unico que se detecta solo.

## 2. Tareas ✅ que no lo estan

Ejecuta la comprobacion de cada una. **De verdad, no de memoria.** Las que
fallen vuelven a ⬜ con una nota de que fallo.

## 3. Los documentos, con el verificador

No revises tu propia documentacion a ojo: lo que escribiste te sigue pareciendo
verdad. Llama al subagente **`verificador-docs`** sobre `que-hacemos.md` y
`como-lo-hacemos.md`. Su trabajo es suponer que toda afirmacion es falsa hasta
que el disco la demuestre, y devuelve **CIERTO · FALSO · SIN COMPROBAR** con la
evidencia de cada una.

Las **FALSO** son la lista de trabajo de este mandato.

> [!warning] Suele estar viejo el documento — pero no siempre
> A veces el que se desvio fue el codigo. Preguntalo antes de reescribir los
> apuntes para que cuadren: cuadrarlos con un error lo convierte en decision.

## 4. Lo que nadie anoto

`git log` contra el diario. Commits sin entrada son contexto perdido:
reconstruyelo desde el diff y anadelo. Y mira si sobrevive un
`.proyecto/retomar-aqui.md` de una sesion vieja — deberia haberse borrado al
retomarla; si sigue ahi, o no se retomo o alguien se lo salto.

## 5. Tareas zombis

⬜ que ya no aplican, ⛔ cuyo bloqueo desaparecio hace tiempo, criterios de
`que-hacemos.md` que dejaron de tener sentido.

## Informa

Una tabla: **qué dicen los apuntes · qué dice el código · qué hacemos**.

Arregla lo evidente, pregunta lo que requiera criterio, actualiza el sello y
termina con un commit.

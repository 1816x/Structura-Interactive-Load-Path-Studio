---
name: trabajar
description: Hacer la siguiente tarea, comprobarla y dejarla anotada
---

<!-- Generado de .claude/commands/trabajar.md por generar-codex.py: mismo mandato, para Codex. Invocalo con $trabajar o /skills. NO editar aqui: se pisa. -->

Una tarea completa, de principio a fin. **O varias a la vez, si el proyecto
lo tiene puesto**: mira el paso 0.

## 0. ¿Una a la vez, o varias?

```bash
grep '^a_la_vez:' .proyecto/ia.yaml; encargar --estado | head -2
```

- **Sin `a_la_vez:`, o `a_la_vez: 1`**: una tarea a la vez. Es lo normal. Sigue
  en el paso 1.
- **Con `a_la_vez: N`** (lo pone el usuario cuando lo pide): tu trabajo es
  **tener N tareas en marcha**. `encargar --estado` dice cuántas van y si cabe
  otra. Por cada una que quepa:
  1. la siguiente tarea que cumpla su regla, sin dependencias
     pendientes y **sin ficheros en comun** con lo que ya corre. Una
     dependencia esta cumplida cuando esta **fusionada en `staging`**: que su
     encargo haya vuelto no basta. Lo que esta en revision cuenta como no
     hecho, porque la revision puede pedir otra ronda;
  2. su worktree, saliendo de `staging`:
     `git worktree add ../<repo>-<n> -b tarea/<n>-<palabras> staging`;
  3. desde alli, `encargar --fichero ENCARGO-<n>.md` como
     **orden de fondo de Claude Code** (sin `--fondo`). Cada uno espera a su
     encargo y te despierta cuando vuelve, con lo que devolvio;
  4. **en el momento**, la tarea a 🔄 en `tareas.md` con su worktree y el ID que
     dio `encargar`. Asi, si llega un `/clear`, la sesion nueva la encuentra.

  El encargo corre aparte: si un `/clear` corta su espera, sigue y la sesion
  nueva lo recoge. **No uses `--fondo`** aqui: ese no espera, nadie te avisa y te
  quedas quieta con el encargo ya de vuelta.

  Cuando vuelve uno, **lo primero es lanzar, no leer**:
  1. sus revisores como encargos (3-bis): unos segundos. No cuentan para
     `a_la_vez`: son parte de su tarea;
  2. si cabe otra, una tarea nueva lista;
  3. despues, lo demas: leer informes, comprobar (4), cerrar en `staging` (5).

  **Cerrar lo empezado va antes que empezar algo nuevo**: revisar y fusionar
  lo que volvió va antes que lanzar otra tarea. Si no, se apilan cambios sin
  fusionar que luego chocan.

  Los pasos 1 a 5 valen igual para cada tarea; cambia solo que no esperas a
  una para lanzar otra. `encargar` no lanza una tarea de más, así que no hace
  falta contarlas a mano.

  Si no queda ninguna tarea lista, se dice en una linea y no se fuerza otra.

## 1. Cual

Lee `.proyecto/tareas.md`. Si $ARGUMENTS trae un numero, esa. Si no, la primera
⬜ sin dependencias pendientes. Marcala 🔄 y **guarda el fichero ya**: si se
corta la sesion, el proximo arranque sabra donde estabas.

### ¿Cabe?

Antes de empezar, mide. Estos limites no son consejo:

| Señal | Que hacer |
|---|---|
| Toca mas de **5 ficheros** | partirla. Sin excepcion |
| Tiene mas de **3 subtareas** | partirla |
| No sabes escribir su comprobacion | **no esta definida**: definela antes de tocar codigo |
| Cambia dos subsistemas a la vez | partirla por el limite entre ellos |

Partir es escribir las nuevas en `tareas.md` y empezar por la primera. Lo que no
cabe se queda a medias, y lo que se queda a medias es lo que se pierde.

### Su rama

**Nunca se trabaja sobre la rama principal.** Cada tarea sale de `staging`, que
es donde aterriza el trabajo terminado:

```bash
git switch staging && git pull -q      # si no existe: git switch -c staging main
git switch -c tarea/<n>-<dos-o-tres-palabras>
```

Aqui trabajas solo, sin nadie que mire por encima. La rama es lo que hace que un
error tuyo **no sea todavia historia del proyecto**: se deshace y no paso nada.
Sobre `main` habria que revertirlo, que es otra cosa.

Si ya estas en una rama `tarea/…` y la tarea es la misma, sigue en ella.

> [!warning] DE `staging`, NO de tu rama anterior
> Salir de la rama de la tarea anterior parece razonable —«necesito lo que
> acabo de hacer»— y crea una pila: cada rama contiene a la anterior. Paso el
> 29 de agosto de 2026 con cinco tareas, y al fusionar la primera las otras
> cuatro dieron conflicto de golpe.
>
> No vuelve a pasar si **cierras cada tarea llevandola a `staging`** (paso 6).
> Entonces `staging` ya tiene tu trabajo anterior y la rama nueva sale limpia.

## 2. Lee solo lo justo

La parte de `como-lo-hacemos.md` que aplique y los ficheros que vas a tocar.
**No leas el proyecto entero** — ese es el habito que llena el contexto de ruido
y hace que el final de la sesion salga peor que el principio.

Mira en `diario.md` si esto ya se intento antes.

## 3. Encargala — tu no la tecleas

**No escribes codigo del producto.** Hay un hook que lo impide, y no es un
descuido: tu trabajo es el juicio, y hay una segunda bolsa de cuota sin usar.

Escribe el encargo. Si es corto, en linea; si es largo, en un `ENCARGO-<algo>.md`
que si puedes escribir:

```
encargar "<que hay que conseguir>" --prueba "<el comando que debe pasar>" <ficheros>
encargar --fichero ENCARGO-login.md
```

Un buen encargo lleva **cuatro cosas**, y sin ellas vuelve mal:

| | |
|---|---|
| **Que conseguir** | el objetivo, no la implementacion |
| **Que NO tocar** | lo que se rompe si lo mueve |
| **Como se comprueba** | el comando exacto que tiene que pasar |
| **El estilo de la casa** | «que encaje con lo que ya hay», si toca codigo existente |

Si toca una pantalla, se sigue la skill `pantallas`: primero **qué nivel es**
(ajuste, pantalla nueva o rediseño, o una pantalla que va a la cola de
rediseño). El encargo lleva siempre `.proyecto/diseno.md` **entero** (el manual
de la interfaz), y en una pantalla nueva o un rediseño además **la intencion de
diseño** que decidio `disenador-interfaz` y la opción que eligio el usuario
**antes** de encargar. Sin eso vuelve generico, cada pantalla sale distinta y se
gastan rondas recuperando lo que el encargo deberia haber dicho.

### No te quedes esperando, y no te quedes colgado

```
encargar --fondo "…"     lo lanza y te devuelve el mando
encargar --estado        ¿sigue corriendo? ¿cuanto lleva? ¿como acabo el anterior?
encargar --leer          el informe entero del ultimo
```

**Un encargo no se corta por reloj**: mientras cambie
ficheros, saque salida o corra pruebas, sigue. Se corta si lleva **20 minutos
atorado** sin hacer nada, o en el techo de seguridad (120 min). Antes se
cortaba a los 15 y se perdian el contexto y el informe de un encargo que iba
bien.

Si se corto, eso **es informacion**: mira `git diff` a ver qué alcanzó a hacer.
Atorado casi siempre es un encargo vago o una orden que se queda esperando:
parte la tarea o dile que no espere.

Mientras corre en segundo plano, adelanta el plan de la siguiente tarea o
prepara la comprobacion. Pero **no empieces a tocar los mismos ficheros**.

### Cuanto esfuerzo

Lo eliges **tu**, que acabas de escribir el encargo. No hay tabla que lo
adivine: tocar tres ficheros puede ser trivial o endiablado.

| | |
|---|---|
| `--facil` | mecanico y evidente: renombrar, formatear, mover algo de sitio |
| *(nada)* | **casi todo**. Es el valor por defecto y acierta la mayoria |
| `--duro` | logica enredada, varios ficheros que dependen entre si, refactor |

**No lo subas por si acaso.** `--duro` tarda mas y gasta mas de una cuota que
no es infinita. Se sube **cuando el encargo vuelve mal**, no antes.

> [!warning] Dificultad observada, no predicha
> «Esto Codex no lo va a poder hacer» casi siempre significa que el encargo era
> vago. Encargalo igualmente. Si falla:
>
> 1. Reencargalo **una vez** con correccion concreta de lo que salio mal.
> 2. Si vuelve a fallar, `--duro`.
> 3. Si con `--duro` tambien falla, ahi si: `tocar-yo`, lo tecleas, y
>    `tocar-yo --fin` al terminar. Y anotalo en el diario.

## 3-bis. Que lo revise un senior

Cuando el encargo vuelve, **antes** de comprobarlo tu, pasa el diff por el
agente `senior-dev`: es un revisor con criterio que cuestiona lo que puede ser
mas eficiente, mas simple o mas seguro, y separa lo que **bloquea** de lo que
es mejora o gusto. **Solo cuando paga** (usuario, 29-10-2026: tres revisores
por tarea agotaban la cuota):
- `senior-dev`: motor, permisos y lo que escribe datos;
- `auditor`: si hay cifras, fechas o totales;
- `paranoico`: una vez por tanda, antes de fusionar a `main`; en la tarea, solo si toca
  credenciales, conexiones o permisos;
- documentación y guías: solo sus pruebas;
- **una pantalla nueva o cambiada: `usuario-novato` y `usuario-experto`**, y no
  se da por terminada sin el «sí» de los dos (skill `pantallas`, paso 8).
  Sustituye a «pulido de pantalla: solo sus pruebas».

Los que tocan, **a la vez**.

Los revisores van **como encargos, no como Agent**: corren aparte, en
paralelo, y tu sigues lanzando. Desde el worktree de la tarea:

```
encargar --claude --perfil senior-dev \
  "Revisa el diff de la tarea N (git diff staging...HEAD). Contexto: <una linea del objetivo>."
encargar --claude --perfil paranoico \
  "Revisa el diff de la tarea N (git diff staging...HEAD) antes de empujarlo."
```

Igual que un encargo de codigo: orden de fondo de Claude Code, sin `--fondo`, y
el ID en `tareas.md` (`senior-dev <ID>`). Con `--perfil` solo leen, asi que
varios caben en el mismo worktree. Si un reencargo cambia el codigo, el
`paranoico` se repite sobre el diff nuevo; el `senior-dev`, solo si lo que
bloqueaba era de fondo.

Con una tarea a la vez vale igual: los dos revisores a la vez, como encargos
(no cuentan como tareas).

- Lo que **bloquea** vuelve a Codex como reencargo concreto («en X:linea, …»).
  No lo arregles tu: el reencargo es mas barato que tu contexto.
- Lo que es **mejora** entra si cabe en la tarea; si no, va como tarea nueva a
  `tareas.md`.
- Lo de **gusto** se anota en el diario y se sigue.

Una ronda. Si tras el reencargo sigue bloqueando, ahi decides tu.

## 4. Compruebalo

Ejecuta la comprobacion de la tabla. **Ejecutala, no la razones.** Si falla,
arregla y repite. Si no puedes comprobarla, dilo en vez de darla por buena.

## 5. Cierra en un solo movimiento

Este es el orden, y **no se rompe**: el codigo y su anotacion entran en el
**mismo commit**.

Si quedan commits de codigo sin su entrada en el diario, el proyecto queda en un
estado que miente: `git log` dice que se hizo algo y nadie sabe que fue. Por eso
se escribe y se commitea seguido, **sin parar a explicar nada por el camino**.

1. Marca ✅ en `tareas.md`.
2. Sella el estado: pon en la cabecera de `tareas.md`

   ```
   estado_escrito_contra: <git rev-parse --short HEAD>
   ```

   Ese sello es lo que permite a `/retomar` **detectar solo** que los apuntes se
   quedaron viejos, en vez de depender de que alguien se de cuenta.
3. Anade al final de `.proyecto/diario.md`:

```markdown
## <AAAA-MM-DD> — Tarea N: <título>

**Hice:** <qué cambió, con los ficheros>
**Comprobé:** <mandato y su resultado>
**Descubrí:** <lo que no sabíamos al planear — quita la línea si no hubo nada>
**No funcionó:** <lo que se probó y falló, y por qué — quita si no hubo>
**Sigue:** <la tarea que toca>
```

4. Un commit con **todo junto**: codigo, `tareas.md` y `diario.md`.
5. Empuja la rama: `git push -u origin HEAD`.
6. **Aterrizala en `staging`**, que es lo que deja el terreno limpio para la
   siguiente tarea:

```bash
git switch staging && git pull -q
git merge --no-ff tarea/<n>-<nombre>
git push
git switch -   # de vuelta a tu rama, por si queda algo
```

Ahi termina tu parte. **A `staging` si llegas tu; a `main` no.**

`staging` es tuyo: es donde se integra y donde se prueba, y si algo sale mal se
arregla ahi sin haber tocado nada estable. `main` es del usuario — lo decide él,
con un pull request de `staging` a `main`.

> [!important] Si la fusion a `staging` da conflicto, PARA
> No lo resuelvas a lo bruto ni fuerces nada. Un conflicto ahi significa que
> otra cosa toco los mismos ficheros, y eso hay que entenderlo antes de
> aplastarlo. Anotalo en el diario y dilo.

Antes de empujar, el cambio tiene que haber pasado por **`paranoico`** (lanzado
en 3-bis, junto con `senior-dev`). Es el ultimo sitio donde una credencial
pegada por descuido se puede quitar sin que quede en el historial.

**Descubri** y **No funciono** son la razon de ser del diario: lo que funciono
ya vive en el codigo, lo que fallo solo vive aqui. Sin ellas se repite el mismo
error dentro de tres sesiones.

Fecha real, con `date +%F`.

> [!warning] El resumen generico no vale
> «Tarea completada», «se implemento la autenticacion» o «varios arreglos» no
> dicen nada. Di **qué** y **con qué**: «login con correo y contraseña, sesion
> en cookie firmada». Si el resumen sirve para cualquier tarea, esta mal escrito.

## 6. Para

Tres lineas de resumen y **pregunta si sigues**. No encadenes tareas por tu
cuenta: cada parada es un punto de guardado.

**Con `a_la_vez` de 2 o más**, la parada es otra: cierras cada tarea que vuelve
(paso 5, que es el punto de guardado) y lanzas la siguiente **sin preguntar**.
Paras cuando no queda ninguna tarea lista, o por el contexto (abajo).

**Mira cuanto contexto queda.** Pasado mas o menos **dos tercios**, no empieces
otra tarea: di que conviene `/guardar` y empezar sesion nueva. Una sesion larga
termina trabajando peor que al principio, y lo caro no es parar — es lo que se
hace mal despues de no haber parado.

Con varias a la vez, el contexto **no las para**: sigue lanzando
hasta que toque reciclar. Los encargos son procesos aparte, siguen solos tras
`/clear`, y cada uno ya esta en `tareas.md` desde que lo lanzaste (paso 0.4).
Lo que no haces cerca del limite es *empezar a cerrar* uno largo (suite,
fusion) si no te cabe: eso vive dentro de esta sesion y con `/clear` se pierde.
Las revisiones no: son encargos y su ID esta en `tareas.md`. Para reciclar: `/guardar`, sin esperar a los encargos
que corren. Hasta el 27-10-2026 aqui ponia «a los dos tercios no lances nada»,
de cuando un encargo lanzado antes del `/clear` se perdia: dejaba el último
tramo de cada sesión sin nada corriendo.

**Un servidor que levantas para inspeccionar** (la app en un puerto, un
`streamlit run` en segundo plano) **lo apagas al terminar de mirar**. No acaba
solo, y mientras corre parece que esperas algo.

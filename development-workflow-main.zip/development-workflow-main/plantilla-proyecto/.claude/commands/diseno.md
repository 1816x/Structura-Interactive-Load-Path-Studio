---
description: Algo de una pantalla no te gusta — lo arregla en todas y no se vuelve a hacer
argument-hint: <qué no te gusta, con tus palabras> (y en qué pantalla, si no es obvio)
---

El usuario te dice algo de la interfaz que no le gusta o no tiene sentido:

$ARGUMENTS

No es solo un arreglo: es una regla que, desde hoy, vale en todas las pantallas
de este proyecto (y quizá de todos). Sigue «Aprender» de la skill `pantallas`.

## 1. Entiéndelo antes de tocar nada

Mira la pantalla de verdad (`ver-pantalla`), no el código. Si no está claro qué
le molesta o dónde, **pregúntale una sola cosa** y espera. Lo que apuntes tiene
que ser lo que él quiso decir, no lo que tú supones.

## 2. Apúntalo, con sus palabras y su motivo

- **En el manual** (`.proyecto/diseno.md`, sección 10 «Reglas aprendidas»):
  la regla concreta, su «Por qué» con sus palabras, «Se vigila: escrita» y el
  origen (pantalla y fecha). Si cambia algo que el manual ya decía (interacción,
  vocabulario, aspecto), corrige también esa sección: el manual no puede decir
  dos cosas.
- **Si vale para todos sus proyectos** (es un gusto, no algo de este negocio):
  además a `.proyecto/gustos-nuevos.md`, con el formato de la skill. Si dudas,
  pregúntale.
- **Si ya estaba escrita** y se volvió a romper: súbela un grado (escrita →
  inspector → prueba automática). Que se repita quiere decir que escrita no
  basta.

## 3. Arréglalo en todas las pantallas, no solo en esa

Busca el mismo fallo en toda la app (en el código y, si hace falta, mirando las
pantallas). Haz la lista con su número: «el aviso en rojo sale en 9 sitios».

- Pocos sitios: un encargo que los arregla todos.
- Muchos, o pantallas en la cola de rediseño: una tarea por pantalla en
  `tareas.md`, o dentro del rediseño que ya tiene.

Es un cambio de interfaz: el encargo lleva el manual entero, y pasa la
verificación de la skill (inspector contra el manual, novato y experto).

## 4. Si se puede comprobar con una prueba, escríbela

Si la regla se puede vigilar en código (un componente que no se usa, un texto
prohibido, un color fuera de los tokens, un botón que siempre va en el mismo
sitio), añade una prueba a la suite del proyecto (p. ej.
`tests/test_interfaz.py`) y pon en la regla «Se vigila: prueba <cuál>».

## 5. Contéstale corto

Qué entendiste, dónde quedó la regla, en cuántos sitios se arregla y si quedó
vigilada por una prueba. Sin repetirle su propia queja.

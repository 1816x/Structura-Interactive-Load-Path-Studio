---
description: Modo día — sigue trabajando sola con el usuario despierto, reciclando el contexto cuando haga falta (/mododia · /mododia parar · /mododia ver)
argument-hint: [parar | ver]
---

El usuario pide el modo día: **$ARGUMENTS**

El mismo vigilante que el modo noche (`noche`, en su ventana tmux), pero con el
usuario **despierto**:
- recicla el contexto (`/guardar` · `/clear` · `/retomar` · `/trabajar`) cuando
  se llena **y** él lleva 20 min sin escribirte;
- te escribe `/trabajar` si llevas 20 min parada con tareas pendientes (con
  freno: si no avanzas, cada vez espera más, y a la tercera lo deja).

Tú **sí preguntas** como siempre: las reglas del modo noche no aplican. Ver la
sección «Modo día» de `CLAUDE.md`.

Solo hay **un** vigilante: encender el modo día apaga el modo noche.

Según lo que haya pedido, corre **una** de estas órdenes con Bash, desde la
carpeta del repo:

| Pidió | Orden |
|---|---|
| nada (encender) | `noche --ver` primero; si ya dice «(dia)», no hagas nada más que decírselo. Si no, `noche "$(basename "$PWD")" --dia` |
| `parar`, `apagar`, `quitar` | `noche --parar` |
| `ver`, `cómo va` | `noche --ver` |

Después, en una o dos líneas: que está encendido (o que ya lo estaba), que lo
apaga con `/mododia parar` y que lo que hizo lo ve con `/mododia ver`. Si estaba
puesto el modo noche, dile que lo cambiaste. Y sigue con lo que estabas haciendo.

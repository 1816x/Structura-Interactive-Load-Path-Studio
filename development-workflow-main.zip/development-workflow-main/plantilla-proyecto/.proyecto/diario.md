# Diario

Se añade al final, nunca se reescribe lo anterior. Lo viejo puede haber quedado
superado; ese es justamente el dato interesante.

Las líneas que más valen son **Descubrí** y **No funcionó**: lo que funcionó ya
vive en el código, lo que falló solo vive aquí.

---

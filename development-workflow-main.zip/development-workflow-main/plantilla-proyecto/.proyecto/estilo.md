# Cómo se escribe aquí

El estándar de la documentación. Deriva de dos sitios: la regla de `CLAUDE.md`
(castellano, sin jerga, «qué hueco cerraba cada cosa», anotar lo que NO
funcionó) y las reglas anti-slop de hallmark (`.claude/skills/hallmark`). Sirve
para que cualquier nota nueva salga igual y para revisar las viejas.

**Slop** es el texto que suena a IA de fábrica: relleno, adjetivos vacíos,
promesas sin dato, andamiaje que no informa. La regla de fondo: **cada frase o
carga un hecho o sobra.**

## Las siete reglas

1. **Verbo concreto, voz activa.** «El script mueve X» antes que «X es movido».
   «Radarr hace hardlink» antes que «se procede a enlazar».

2. **Nombra lo que pasó.** Un aviso dice *qué* rompe, *por qué* y *cómo se
   arregla*, en ese orden. Nada de «algo salió mal»: di qué salió mal.

3. **Datos reales o el hueco.** Un número inventado es slop. Si no lo tienes,
   escribe `—` o «por confirmar», nunca una cifra de relleno.

4. **Qué hueco cerraba.** Cada automatismo, servicio o decisión abre diciendo
   el problema que resolvía, no solo qué hace. El «para qué» antes que el «qué».

5. **Anota lo que NO funcionó.** Lo que funcionó ya está en el código. Los
   callejones sin salida solo sobreviven si se escriben, y son los que evitan
   repetir el error dentro de un año.

6. **Un nombre por cosa.** Si es «el limpiador», es «el limpiador» en todas
   partes, no «el script de pistas» en la siguiente línea.

7. **Sin relleno.** Fuera «es importante destacar que», «cabe mencionar»,
   «en el mundo actual», «robusto», «potente», «sin fisuras», «de vanguardia».
   Si quitas la frase y no se pierde nada, quítala.

## Avisos (callouts)

Un solo sistema, el de los avisos de GitHub:

```
> [!warning]  cuidado, esto muerde
> [!danger]   esto rompe algo o borra datos
> [!tip]      atajo o buena práctica
> [!important] regla que no se negocia
> [!note]     dato de contexto
> [!info]     de dónde sale esto / metadatos
```

**No usar emoji como marca de sección** (`⚠️`, `✅`, `❌` al inicio de línea).
Es una firma reconocible de texto generado, y cada dispositivo los pinta
distinto. Dentro de una frase, para marcar sí/no en una tabla, valen.

## Tipografía

- Raya para incisos: `—`. Rango: `10–20`. Nunca `--` (salvo en comandos).
- Puntos suspensivos: `…`, no `...`.
- **No tocar los bloques de código.** Ahí `--profile`, `-a`, `|---|` son
  correctos y cambiarlos rompe el comando.

## La forma

- **Tablas** para lo que se compara (esto vs. aquello, ruta → qué guarda).
- **Bloques de código** para comandos y rutas exactas, tal cual se teclean.
- Secciones cortas y autocontenidas: quien busca una cosa la encuentra sin
  leer lo de antes. Ayuda además a que el modelo local recupere el fragmento
  con su ejemplo dentro.
- Fechas absolutas: «el 15 de agosto de 2026», no «ayer» ni «hace poco».

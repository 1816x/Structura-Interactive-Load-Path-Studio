# Tareas

⬜ pendiente · 🔄 en curso · ✅ hecha · ⛔ bloqueada · ❌ descartada

_Todavía sin planear. Usa `/planear` para empezar._

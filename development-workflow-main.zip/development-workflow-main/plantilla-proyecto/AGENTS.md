<!-- Codex lee este fichero siempre (equivale a CLAUDE.md para Claude Code).
     El contenido común está en CLAUDE.md; aquí solo lo que cambia cuando
     conduce Codex. Mantenlos alineados. -->

Lee `CLAUDE.md`: son las reglas del proyecto y valen igual para ti.

## Cuando conduces tú (Codex)

- Los comandos `/retomar`, `/planear`, `/trabajar`, `/guardar`, `/revisar`,
  `/modonoche`, `/mododia`, `/diseno` son **skills**: `$retomar`, `$planear`… (o `/skills`).
  Mismo contenido que para Claude.
- **No tecleas código del producto**: lo encargas con `encargar "…"` (por
  defecto se lo manda a **Claude**, el otro motor). Para una revisión con
  criterio: `encargar --claude --perfil senior-dev "revisa el diff de la tarea N"`.
- Tus subagentes propios (`.codex/agents/*.toml`) son los mismos perfiles que
  `.claude/agents/`: `senior-dev`, `paranoico`, `abogado-del-diablo`…
- El modelo local, si lo hay: `ia-local`.
- El hook de `.codex/hooks.json` es la guardia que impide editar el producto
  (la primera vez, confíalo con `/hooks`).

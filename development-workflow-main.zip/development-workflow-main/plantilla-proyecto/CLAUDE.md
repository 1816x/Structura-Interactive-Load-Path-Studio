# Cómo se trabaja aquí

El estado del proyecto vive en `.proyecto/`, **no en la conversación**. La
conversación es desechable; los ficheros son la memoria.

## Los comandos

| | |
|---|---|
| `/retomar` | **¿Dónde me quedé?** — con esto empieza toda sesión |
| `/planear` | **¿Qué construimos y cómo?** — una vez, al principio |
| `/trabajar` | **Haz lo siguiente** — una tarea, comprobada y anotada |
| `/guardar` | **Me voy** — con esto termina toda sesión |
| `/revisar` | **¿Los apuntes siguen siendo verdad?** — cada pocas sesiones |
| `/diseno` | **Esto de la pantalla no me gusta** — se arregla en todas y no se repite |

Proyecto nuevo: `/planear` una vez, luego `/trabajar` tantas veces como haga
falta, y `/guardar` al irte. Al volver, `/retomar`.

## Los cuatro ficheros

| | |
|---|---|
| `.proyecto/que-hacemos.md` | Qué se construye, para quién, qué queda fuera |
| `.proyecto/como-lo-hacemos.md` | Decisiones **y por qué**, con lo descartado |
| `.proyecto/tareas.md` | Estado de cada tarea y cómo se comprueba |
| `.proyecto/diario.md` | Qué se hizo, qué se descubrió, qué **no** funcionó |

## Reglas

1. Toda sesión empieza con `/retomar` y termina con `/guardar`, aunque sea a
   medias.
2. Una tarea, un commit, con los ficheros de `.proyecto/` incluidos.
3. Nada se da por hecho sin ejecutar su comprobación. Razonar que algo funciona
   no es comprobarlo.
4. El código manda sobre los apuntes. Si discrepan, los apuntes están viejos.
5. Lo que **no** funcionó se escribe. Lo que funcionó ya está en el código.

## Modo noche

Si existe `~/.proyecto-noche`, el usuario está **dormido** y un vigilante te
escribe `/trabajar` cada vez que te paras, y `/guardar` + `/clear` +
`/retomar` cuando se te llena el contexto o se compacta. Lo enciende y lo
apaga él con `/modonoche`. **Si te escribe, es que sigue despierto**: contéstale con normalidad
(el vigilante no teclea mientras él haya escrito en los últimos 3 minutos).
Mientras exista ese fichero:

- **No lo apagues tú** (`/modonoche parar`), aunque te parezca que ya es de día.
  Es un interruptor suyo: solo lo apaga él, o tú si te lo pide.
- **Una pantalla con varias opciones de maqueta:** construye la que recomiendas,
  no te pares a esperar su elección. Al despertar puede pedir otra.
- **No preguntes nada, ni pidas confirmación.** Nadie va a contestar hasta la
  mañana, y la sesión se quedaría parada.
- **Si una tarea necesita una decisión suya**, márcala ⛔ en `tareas.md` con la
  pregunta exacta y pasa a la siguiente que no la necesite. Si tienes que
  decidir algo **reversible**, decide, y apunta en el diario qué elegiste y por
  qué, para que él lo revise.
- **Nada irreversible ni delicado:** ni borrar datos, ni tocar autenticación o
  seguridad, ni migraciones destructivas, ni nada fuera de tu rama. Eso se queda
  ⛔ para la mañana.
- Cada tarea termina **commiteada y empujada a su rama**. El vigilante para la
  noche si pasan 3 rondas sin un commit nuevo.
- Al terminar una tarea, termina el turno. No encadenes tú la siguiente: lo
  hace el vigilante, que es quien decide cuándo hace falta reciclar el
  contexto.

**Modo día** (`/mododia`, marca `~/.proyecto-dia`): el usuario está
**despierto**. El mismo vigilante recicla el contexto (`/guardar` · `/clear` ·
`/retomar` · `/trabajar`) cuando lleva 20 min sin escribirte, y te escribe
`/trabajar` si te quedas parada con tareas pendientes. Aquí **sí preguntas**
como siempre: nada de la lista de arriba aplica.

Al terminar una tarea, **no cierres con «¿sigo?»**: di cuál toca después
(«Sigue: X») y termina el turno. Si el usuario no dice nada, el vigilante te
escribe `/trabajar` a los 5 min. Si cierras con una pregunta, espera 20 para
dejarle contestar: pregunta solo lo que de verdad necesitas de él.

Solo hay un vigilante: encender el día apaga la noche y al revés. **Si te piden
encenderlo, mira antes `noche --ver`**: puede estar ya puesto.

## Cómo hablarle al usuario

Vale para todos sus proyectos:

- **En su idioma**, también los resúmenes y lo que relayas de un subagente.
- **Corto: el mejor camino, el riesgo y la orden o el script.** Sin tablas de
  tres opciones ni idas y vueltas: «dame un script y ya, no back and forth 100
  veces». Recomienda y actúa; si hace falta un dato suyo, una consulta de una
  fila y una frase de qué mide.
- **Palabras que se entienden.** Di lo que hace, no la jerga: «purgar» no se
  entendía, «borrar las corridas que ya no sirven» sí. En pantallas y botones
  también.
- **Capturas del front:** cada maqueta o pantalla que cambia, mándasela con
  `SendUserFile` y una línea de qué muestra (en el móvil no ve el navegador de
  la máquina de desarrollo). Sin parar el trabajo para eso.

## Si el usuario te sigue desde el móvil

Con Remote Control, **`! orden` no existe**: Claude Code contesta «Shell
commands are only available in local sessions». Nunca le pidas que teclee algo
con `!`.

- **Si puedes correrlo tú, córrelo tú.** No se lo pases.
- **Si tiene que correrlo él** (lee datos que tú no debes ver, pide su
  contraseña o es interactivo), dale la orden ya armada y lista para pegar en
  su terminal, y dile qué tiene que contarte («dime si sale OK o cuántos
  fallan»). Si la orden saca datos privados, que te diga el resumen y no pegue
  la salida.

Si el proyecto cabe en una tarde, sáltate esto: la ceremonia debe pagar lo que
cuesta.

---

# Cuándo pedir ayuda a otro

Aquí trabajan varias IAs. Tú conduces; las demás son consultores. Delegar tiene
un coste —escribir el encargo y leer la respuesta— así que **solo se delega
cuando ese coste se paga.**

## Los verificadores

Viven en `.claude/agents/`. Son personas con un criterio, no ayudantes
genéricos, y el arnés les aplica su modelo: no hay que acordarse de nada.

| A quién llamas | Cuándo |
|---|---|
| `abogado-del-diablo` | al cerrar **un diseño**, no después. Busca por dónde se rompe |
| `paranoico` | antes de **cada push**. Secretos, permisos, puertos, y datos de personas o del negocio que no debían salir |
| `antislop` | antes de dar por buena **documentación**. Solo quita; no reescribe |
| `verificador-docs` | cuando algo «no cuadre». Contrasta cada afirmación contra el disco |
| `senior-dev` | sobre **cada diff** que vuelve de un encargo, antes de comprobarlo tú. Separa lo que bloquea de lo que es mejora o gusto |
| `auditor` | sobre cambios que tocan **dinero, fechas o totales**. Escribe casos incómodos y los corre: ¿algún número mal, algo que no cuadre? |

Y para pantallas, seis trabajos **distintos** que no hay que mezclar:

| | Contesta a |
|---|---|
| `disenador-interfaz` | **qué** se enseña y en qué orden. Antes de que exista código |
| la skill `hallmark` | **cómo** se ve: tipografía, paleta, ritmo. La piel, no la estructura |
| la skill `marca` | **de quién** es: si existe `.proyecto/marca.yaml` (p. ej. `preset: mi-empresa`), sus colores, fuentes y logo **mandan sobre hallmark** |
| `inspector-pantalla` | ¿está bien **construido** y es **como las demás**? Mide contra el manual: interacción, vocabulario, aspecto y estados |
| `usuario-novato` | ¿puedo **terminar mi trabajo**? Abre la aplicación y pulsa, sin saber nada de ella |
| `usuario-experto` | ¿cuánto me cuesta **repetirlo**? Clics, esperas y volumen de quien la usa a diario |

> [!warning] El error que más caro sale en front-end
> Empezar por la piel. La pantalla sale con la forma de la base de datos —un
> campo por columna, todo presente, nada jerarquizado— y luego se le pone una
> tipografía bonita encima. Sigue siendo inservible, pero ahora es bonita.
> **`disenador-interfaz` va primero, siempre.**

**Todo cambio de pantalla sigue la skill `pantallas`**, también los ajustes
pequeños. El centro es **`.proyecto/diseno.md`, el manual de la interfaz**:
para quién, sus tareas, el marco, cómo se comporta todo, el vocabulario y el
aspecto. Cada encargo de front lo lleva entero y el inspector mide contra él;
es lo que hace que veinte pantallas parezcan de la misma app. La skill dice
cuánto proceso pide cada cambio (ajuste, pantalla nueva o rediseño, repaso) y
qué hacer si ya hay muchas pantallas sin manual (modo rescate).

**Lo que el usuario diga de una pantalla se aprende**, venga por `/diseno` o
por el chat: queda como regla en el manual con sus palabras, se arregla en
todas las pantallas donde pase, y si se puede, lo vigila una prueba.

Se invocan con la herramienta Agent, **salvo los que revisan el diff de un
encargo** (`senior-dev`, `paranoico`, `auditor`): esos van como encargos,
`encargar --claude --perfil <nombre>`, a la vez y sin parar a la sesión
(`/trabajar`, paso 3-bis). **Su respuesta es una opinión, no una
orden**: si `usuario-novato` se queja de algo que es correcto, se le
contesta y se sigue.

> [!warning] Un verificador nuevo no existe hasta reiniciar la sesión
> Claude Code lee `.claude/agents/` al arrancar. Si acabas de crear uno —o
> alguien actualizó la plantilla mientras trabajabas— dará «agent type
> not found» aunque el fichero esté bien. Se sale y se vuelve a entrar.

## El modelo local

`ia-local` (opcional) habla con un modelo que corre en tu propia red y está
**aislado de internet**: lo que se le manda no sale de ahí.

Le queda **un solo trabajo, y es insustituible**: material que no debe salir
de tu red. Correo, notas, cualquier cosa privada.

Para todo lo demás está Codex, que es mejor que cualquier modelo que quepa en
una tarjeta doméstica. El local es lo único **de verdad ilimitado**, pero eso
solo importa cuando la privacidad manda.

> [!warning] Para qué NO sirve
> **Revisar prosa.** Se midió dos veces: condenó una frase correcta por estar
> pegada a una mala. Para eso está `antislop`, que es un subagente de Claude.
>
> **Volumen de trabajo mecánico.** Eso va a Codex: acierta más y no es mucho
> más caro en la práctica.
>
> **El primer uso tras un rato es lento**: el modelo se descarga de la memoria
> de vídeo a los pocos minutos. Si vas a preguntarle varias cosas, hazlas
> seguidas.

```
ia-local --lista       qué servidores contestan y qué modelos tienen
ia-local --registro    qué se ha delegado, cuánto tardó y cuánto ocupó
```

## Aquí no se teclea código del producto

Hay **dos bolsas de cuota**: la de Claude y la del plan de ChatGPT (Codex). Tu trabajo es el **juicio** —planear, decidir,
escribir el encargo, revisar el diff—; teclear el código no es donde aportas.

> [!important] La regla, y no tiene excepciones por tamaño
> **No editas ficheros del producto.** Ni un cambio de una línea. En cuanto la
> regla admite excepciones, vuelve a ser un consejo que se olvida.
>
> Y no es una intención: **hay un hook que lo bloquea**. Si lo intentas, el
> arnés te lo impide y te recuerda cómo encargarlo.

Lo que **sí** escribes aquí: `.proyecto/` (la memoria), `.claude/`, y los
ficheros `ENCARGO*` de especificación.

```
encargar "<qué conseguir>" --prueba "npm test" src/login.js
encargar --fichero ENCARGO-login.md
encargar --leer [ID]     qué devolvió ese encargo (o el último)
encargar --fondo "…"     lo lanza y te devuelve el mando
encargar --estado        qué hay corriendo y cómo acabaron los últimos
```

### Varios encargos y varias cuentas

- **Por defecto, un encargo a la vez.** En paralelo **solo si el usuario lo
  pide con esas palabras** («varios a la vez», «en paralelo»). «Monta todo» o
  «nada por fases» habla del alcance, no de lanzar varios: leerlo así puso
  cuatro a la vez y la máquina se quedó sin memoria. Se pone
  con `a_la_vez: N` en `.proyecto/ia.yaml`, y entonces:
  - cada encargo en **su propia copia del repo**: `git worktree add
    ../<repo>-<tarea> -b tarea/<id>`, y el encargo se lanza desde ahí.
    `encargar` se niega a lanzar dos en la misma carpeta;
  - tareas que **no toquen los mismos ficheros**. Si dos lo hacen, van en serie;
  - se fusionan **de una en una** a `staging`, con la suite completa después de
    cada fusión. Si la segunda choca con la primera, se rehace sobre la nueva
    base: no se resuelve a ojo;
  - `encargar --estado` los lista todos y `encargar --leer <ID>` lee uno.
- **Cuentas.** Los encargos van a `cuenta_encargos:` de `.proyecto/ia.yaml`.
  Con varias (`cuenta_encargos: segunda, tercera`), los encargos van **por
  turnos** (uno y uno). Con tope (`cuenta_encargos: segunda:2, personal:1`),
  cada cuenta lleva como mucho ese número a la vez, y en serie el mismo peso
  (dos a `segunda` por uno a `personal`). Si todas están en su tope, `encargar`
  no lanza: espera a que acabe uno. Si una se queda **sin cuota**, la marca una
  hora y relanza el mismo encargo con la siguiente; si no queda ninguna, lo dice
  y para.
**Nunca te quedas colgado, y no se corta lo que avanza.** Un encargo sigue
mientras cambie ficheros, saque salida o corra pruebas; se corta si lleva 20
minutos atorado (o a los 120, techo de seguridad). Que se corte **es
información**: mira `git diff` a ver qué alcanzó. Atorado casi siempre es un
encargo vago.

**La dificultad la eliges tú**, que acabas de escribir el encargo: `--facil`
para lo mecánico, nada para casi todo, `--duro` para lógica enredada. No lo
subas por si acaso — se sube cuando el encargo vuelve mal, no antes.

**Un encargo sin criterio de aceptación vuelve mal.** Siempre lleva: qué hay
que conseguir, qué **no** se toca, y **el comando exacto que debe pasar**.

**Y al final de todo encargo de código, esta lista**, copiada tal cual. Sale de
lo que `senior-dev` encontraba después, cuando cada hallazgo costaba otra ronda
de encargo (medido: 4 de 5 rondas de corrección):

> Antes de entregar, demuestra con una prueba cada punto que aplique:
> 1. **Dos veces:** ejecutar o guardar dos veces da el mismo resultado, sin duplicados.
> 2. **Falla a la mitad:** si algo truena a medio camino, no queda nada a medias.
> 3. **«Ok» de verdad:** si la operación no cambió nada, no responde «ok».
> 4. **Vacío:** sin datos o con alcance vacío, no hace nada raro.
> 5. **No pierde lo que traía:** marcas, historia y escenario siguen igual.
> 6. **Valores:** las pruebas comparan cifras esperadas, no solo que corre.
> 7. **Córrelas tú:** antes de entregar, corre las pruebas de los ficheros que
>    tocaste (`.venv/bin/python -m pytest -q <ficheros>` si hay `.venv`) y
>    entrega en verde. La suite entera no.
> 8. **Quién más lo usa:** busca quién más llama a lo que cambias y corre
>    también esas pruebas.
> 9. **Lo que ve el usuario:** las pruebas de pantalla comprueban lo que se ve,
>    no detalles internos del framework.

**Para que vuelva bien a la primera** (medido: 10 de 10 rondas de encargos que
no podían ejecutar volvieron en rojo; 2 de 2 que sí, a la primera):
- Si algo depende de cómo es un entorno al que no llegas (columnas, ids,
  tipos del entorno de pruebas), pídele el dato al usuario **antes** de lanzar y ponlo en el
  encargo. No dejes que el encargo lo suponga.
- Una ronda, un objetivo: primero que funcione y se cierra; el pulido va
  aparte, dos o tres puntos por ronda.

`senior-dev` revisa igual que siempre; la lista solo hace que encuentre menos.

**Codex no ve tu memoria** (`~/.claude/projects/…`): ve `AGENTS.md` →
`CLAUDE.md`, `.proyecto/` y las skills. Lo que un encargo tenga que respetar
(una carpeta que no se lee, una palabra que no va en lo que se entrega) va en
`CLAUDE.md` o en `.proyecto/como-lo-hacemos.md`, o escrito en el encargo; nunca
solo en tu memoria. Y en el encargo, **la orden exacta** de sus pruebas: otra
forma de llamar a Python le pide permiso y se queda parado.

**Cada push pasa por un detector de secretos** (un hook `pre-push` de git, sin
modelo; p. ej. gitleaks). Si para un
valor de prueba inventado, su huella va a `.proyecto/secretos-permitidos`.
**Nunca `--no-verify`**: esa decisión es del usuario.

**El código va sin comentarios**, también lo que teclees
tú con `tocar-yo`. Ni números de tarea ni historia: eso está en el diario y en
git. Una trampa va a `como-lo-hacemos.md` o a la skill y la vigila una prueba.
`encargar` ya se lo pide a cada encargo y `senior-dev` lo bloquea.

**Por funcionalidad, no por capas** (back y front por separado dejaron acciones
sin botón y pantallas sin back). Si el
proyecto tiene interfaz, la unidad de trabajo es la **funcionalidad**: se hace
entera, de la acción a la pantalla, y solo se cierra cuando **se puede hacer
desde la pantalla** y tiene el «sí» de `usuario-novato` y `usuario-experto`.
Por dentro, tareas pequeñas seguidas (acción → fachada → pantalla), cada una
fusionada al cerrarse; no se suelta a medias para empezar otra. No se abre back
sin su pantalla, salvo infraestructura que no tiene botón. Dos funcionalidades
van en paralelo solo si no tocan los mismos ficheros.

**Varias a la vez:** solo si `.proyecto/ia.yaml` tiene `a_la_vez: N` (lo pone
el usuario cuando lo pide). Entonces van hasta N tareas, cada una en su worktree
y con `encargar` como orden de fondo; `encargar --estado` dice cuántas van y si
cabe otra, y `encargar` no lanza una de más. Las revisiones no cuentan. Lo
cuenta `/trabajar`, paso 0. **Sin la línea, una a la vez.**

**Esperar encargos en segundo plano:**
- Con varios a la vez, atiende **el primero que termine** (`encargar --estado`)
  y sigue; no esperes a que acaben todos para revisar el primero.
- Lánzalos **sin `--fondo`**, como orden de fondo de Claude Code: cada uno
  espera a su encargo y te despierta al volver. El encargo corre aparte y
  sobrevive al `/clear`. Con `--fondo` nadie te avisa.
- La salida de un encargo se lee con `encargar --leer <ID>`, no con tuberías.
- Si la prueba falla, la siguiente corrida ya con `-rA` o `-x`: no repitas la
  misma para ver el error.

Cuando vuelva: **revisa el diff**. De ahí salen el commit y la propuesta — eso
no se delega.

> [!warning] La cuota de Codex NO es infinita
> El plan más barato es una **segunda bolsa, no un grifo**. Si Codex dice
> que se agotó, los encargos siguen con **Claude, en la cuenta de
> `cuenta_encargos:`** (la que tiene la sesión iniciada), sin
> preguntar: se lo dices al usuario en una línea y sigues. Lo que no se hace es
> teclearlo aquí a escondidas.

> [!tip] Dificultad observada, no predicha
> «Esto Codex no puede hacerlo» casi siempre significa que el encargo era
> vago. Encárgalo primero. Si falla, reencárgalo **una vez** con corrección
> concreta. Si vuelve a fallar, ahí sí: `tocar-yo`, lo tecleas, y
> `tocar-yo --fin` al terminar.

Los motores y las cuentas están en `.proyecto/ia.yaml`. Ese fichero lo leen
los scripts, no tú: cambiarlo cambia el comportamiento de verdad.

---

# Git: tu terreno es staging

Trabajas solo, sin nadie que mire por encima. La rama es lo que hace que un
error tuyo **no sea todavía historia del proyecto**.

Hay **tres niveles**, y cada uno tiene un dueño:

| | Quién manda | Qué es |
|---|---|---|
| `tarea/…` | tú | una tarea. Se tira sin coste |
| `staging` | **tú** | donde se integra y se prueba |
| `main` | el usuario | lo estable. Tú no lo tocas |

```
/trabajar   →  git switch staging && git pull -q
               git switch -c tarea/<n>-<nombre>
               … código y anotación en el mismo commit …
               git push -u origin HEAD
               git switch staging && git merge --no-ff tarea/<n>-<nombre> && git push
```

> [!warning] La rama nueva sale de `staging`, NUNCA de la tarea anterior
> Salir de la anterior parece razonable —«necesito lo que acabo de hacer»— y
> crea una pila donde cada rama contiene a la de antes. Pasó el 29 de agosto de
> 2026: cinco tareas apiladas, y al fusionar la primera las otras cuatro dieron
> conflicto a la vez. Cerrando cada tarea contra `staging` no ocurre.

**A `main` no llegas, y es a propósito.** Si algo se descontrola aquí dentro, lo
peor que puede pasar es que `staging` quede hecho un lío — y `staging` se
rehace. El usuario decide qué sube: un pull request de `staging` a `main`, o
un `git merge` suyo. Ponle fácil decidir: una línea por cambio.

Tras una fusión suya, aquí: `git switch staging && git pull`.

> [!important] Esta máquina es para DESARROLLAR, no para dar servicio
> Si el proyecto es algo que corre solo (un recolector, un temporizador, un
> servicio), **en producción no corre aquí**: corre donde el usuario tenga sus
> servicios, desde un checkout de `main`, con su instalador y su `--help`.
> Tu trabajo es que el repositorio traiga ese instalador; el despliegue no es
> cosa de esta máquina.

> [!important] `paranoico`: una vez por tanda, y en la tarea si toca secretos
> Sobre `git diff main...staging`, antes de que el usuario fusione a `main`. Y
> sobre una tarea suelta, antes de empujarla, si toca credenciales, conexiones
> o permisos: las ramas también suben a GitHub, y una credencial que llega ahí
> ya no se borra: se rota. (Antes era en cada push, y
> agotaba la cuota.)

---

# Al documentar

Cada sesión deja escrito lo que pasó, en el momento, no al final. Lo escribes
para dos lectores: **la próxima IA, que no recordará nada**, y **una persona
dentro de un año**.

El estándar está en `.proyecto/estilo.md`. Lo que más se incumple:

- **Qué hueco cerraba**, antes de qué hace.
- **Lo que NO funcionó.** Lo que funcionó ya está en el código; los callejones
  sin salida solo sobreviven si se escriben.
- **Datos reales o el hueco (`—`).** Una cifra inventada es el peor slop.
- Sin emoji como marca de sección. Sin «robusto», «potente», «sin fisuras».

Antes de dar por buena una nota larga, pásala por `antislop`.

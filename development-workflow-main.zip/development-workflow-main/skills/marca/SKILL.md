---
name: marca
description: "Aplica la identidad de marca de un proyecto (colores, tipografía, logo, proporciones) a su interfaz, desde un preset. Úsala siempre que vayas a crear o cambiar una pantalla, un informe o un gráfico en un proyecto que tenga `.proyecto/marca.yaml`, y cuando el usuario pida «con la marca de X»."
---

# Marca

**El hueco que cierra:** cada sesión elegía colores y tipografía a su gusto. Dos
herramientas de la misma empresa salían con dos «marcas» distintas, y ninguna
era la de la empresa. Un manual de marca está pensado para carteles y camiones,
no para una tabla con 500 filas: alguien tiene que traducirlo a pantalla una
vez, y que todas las apps usen esa traducción.

## Qué preset usa este proyecto

Lo dice `.proyecto/marca.yaml`, en el repositorio:

```yaml
preset: mi-empresa
```

- **Si no existe ese fichero**, el proyecto no tiene marca: no uses esta skill y
  decide la piel con `hallmark`.
- **Si el preset no existe** en `presets/`, dilo y para. No inventes una marca.

Los presets están en la carpeta de esta skill: `presets/<nombre>/`.

## Quién manda

| | Decide |
|---|---|
| **El preset** | colores, tipografía, logo, nombre de la marca. **Gana siempre** |
| `hallmark` | ritmo, espaciado, anti-slop… **dentro** de la paleta y las fuentes del preset. Si hallmark propone un color o una fuente, el preset lo sustituye |
| `disenador-interfaz` | qué va en la pantalla y en qué orden. La marca no cambia la estructura |

La marca es la piel. Una pantalla abarrotada con los colores correctos sigue
siendo una pantalla abarrotada.

## Cómo se aplica

1. **Lee el `README.md` del preset entero** antes de tocar nada. Tiene reglas
   que no están en los tokens (lo que está prohibido, la proporción de colores).
2. **Copia los tokens al proyecto una sola vez**, con el fichero que toque según
   la tecnología (`tokens.css`, `streamlit.toml`, `graficos.json`…). Ponlo en el
   sitio donde el proyecto guarda sus estilos y anótalo en
   `.proyecto/como-lo-hacemos.md`.
3. **Los componentes solo usan tokens.** Ningún `#0000B3` ni `font-family`
   escrito a mano fuera del fichero de tokens. Se comprueba así:
   `grep -rnE '#[0-9a-fA-F]{6}\b' <carpeta del código> | grep -v <fichero de tokens>`
   Debe salir vacío, o con excepciones justificadas en un comentario.
4. **Los gráficos usan la serie del preset**, en su orden, no la paleta por
   defecto de la librería.
5. **Al terminar la pantalla**, revisa la lista «Antes de dar por buena» del
   preset. Si `inspector-pantalla` está disponible, pásale también esa lista.

## Lo que esta skill NO hace

- No baja logos ni ficheros de la marca. El README del preset dice de dónde se
  sacan; los pone el usuario o la sesión, con su permiso, en el proyecto.
- No decide la estructura de la pantalla ni la densidad. Eso va antes.
- No aplica reglas de imprenta (Pantone, CMYK, vehículos, señalética). El
  preset ya las quitó o las tradujo a pantalla.

## Añadir una marca nueva

Una carpeta `presets/<nombre>/` con:

- `README.md`: **de dónde sale** (URL y fecha de la lectura), las reglas del
  manual que aplican a pantalla, **la traducción a interfaz**, marcando qué es
  del manual y qué es interpretación nuestra, lo prohibido, y la lista «Antes de
  dar por buena».
- Los tokens en los formatos que usen los proyectos (`tokens.css` como mínimo).

Si el manual no da un dato (un ángulo, un tamaño mínimo), escribe «por
confirmar». **Nunca un valor inventado**: con una marca de empresa, un dato
falso acaba en todas las apps.

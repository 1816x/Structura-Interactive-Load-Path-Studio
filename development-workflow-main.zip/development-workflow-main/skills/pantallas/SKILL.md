---
name: pantallas
description: "Cómo se diseña la interfaz de un proyecto con los agentes: el manual de la interfaz (.proyecto/diseno.md), tres niveles según el tamaño del cambio, el modo rescate para apps que ya tienen muchas pantallas sin manual, y cómo aprende del feedback del usuario (/diseno). Úsala SIEMPRE antes de escribir o cambiar interfaz, aunque sea un ajuste (nivel 1), y cuando el usuario diga que algo «se ve mal», «está amontonado», «no se entiende» o «no tiene sentido»."
---

# Pantallas

**El hueco que cierra:** las interfaces salían feas e
**inconsistentes**: cada pantalla bien por separado, pero cada una con su forma
de guardar, de filtrar, de avisar y de llamar a las cosas (en un
proyecto con 19 pantallas, y aun con `usuario-novato` y `usuario-experto`
dando el visto bueno). Dos causas:

- **Se diseñaba parche a parche.** El backlog va por temas, no por pantallas:
  una sola pantalla acumulaba 30 tareas, cada una diseñada por alguien que solo
  veía la suya. Treinta parches correctos dan una pantalla incoherente.
- **No había reglas de comportamiento escritas.** El `diseno.md` de entonces
  fijaba el aspecto (densidad, espaciado, letra), no cómo se comporta la app.
  `disenador-interfaz` hacía bien su pantalla, pero no tenía contra qué ser
  consistente.

Antes el problema era otro, «todo muy amontonado», y lo cerró el
orden de pasos que sigue más abajo (nivel 2).

---

## Antes de nada: el manual y los gustos

Lee **siempre**, antes de tocar una pantalla:

1. **`.proyecto/diseno.md`, el manual de la interfaz del proyecto.** Entero.
2. **`gustos/Gustos.md` y `gustos/Referencias.md`**, en la carpeta de esta
   skill: lo que el usuario dijo en todos sus proyectos.
   - **Reglas firmes**: se cumplen sin discutir.
   - **Preferencias** y **Recién recogidos**: son el punto de partida. No le
     propongas lo que ya rechazó. Como mucho **una** opción de una maqueta
     puede ir contra una preferencia, marcada «exploratoria: va contra tu
     gusto X, por si cambiaste de opinión».
   - Mira **«Aplica a»**: lo que vale para una herramienta de datos puede no
     valer para una web.
   - **Sus ejemplos** están descritos en texto. Guíate por lo que él escribió.
     No abras la app o la web para «interpretar» su estilo, salvo que la línea
     lo pida.

Si el manual y un gusto chocan, manda el manual: es más reciente y es de este
proyecto. Díselo al usuario.

## El manual de la interfaz: `.proyecto/diseno.md`

Uno por proyecto. Plantilla: [`plantillas/diseno.md`](plantillas/diseno.md).
Es lo que hace que veinte pantallas parezcan de la misma app:

| Sección | Qué fija |
|---|---|
| 1 · Para quién | quién, cada cuánto, cuánto dato, qué dispositivo |
| 2 · Las tareas | las 5 o 6 cosas que viene a hacer, con su recorrido |
| 3 · Las pantallas | cada una con su trabajo en una frase, y su estado |
| 4 · El marco | la navegación y la barra superior: qué lleva cada una |
| 5 · Interacción | una sola forma de: acción principal, detalle, editar y guardar, confirmar, filtrar, lo largo, mensajes, estados |
| 6 · Vocabulario | un nombre por concepto |
| 7 · Aspecto | densidad, espaciado, letra, tokens, componentes |
| 8 y 9 | fronteras del producto y móvil |
| 10 · Reglas aprendidas | lo que dijo el usuario, con su motivo y cómo se vigila |
| 11 · Elegido y rechazado | cada decisión, con lo descartado y por qué |

**Quién lo escribe:** tú, una vez, antes de la primera pantalla. En un proyecto
nuevo, con el usuario (paso 1). En uno que ya tiene pantallas, **lo decides tú**
a partir de lo que hay: es el modo rescate.

**Quién lo usa:** `disenador-interfaz` diseña dentro de él; cada encargo de
front lo lleva; `inspector-pantalla` mide contra él. Sin manual, el inspector
solo opina.

---

## Tres niveles: cuánto proceso pide cada cambio

| Nivel | Cuándo | Qué se hace |
|---|---|---|
| **1 · Ajuste** | un cambio dentro de una pantalla que ya está al día con el manual: un campo, una columna, un texto, un botón | el encargo lleva el manual; sin maqueta. Al terminar, `inspector-pantalla` (contra el manual) y el visto bueno de `usuario-novato` y `usuario-experto` |
| **2 · Pantalla** | una pantalla nueva, un rediseño, o cualquier cosa que pida un **patrón nuevo** | los pasos 0 a 8, de abajo |
| **3 · Repaso** | una pantalla con **5 o más tareas pendientes**, o que aún no está al día con el manual; y **una vez por semana**, un barrido de toda la app contra el manual | sus tareas se juntan en **un solo rediseño** de nivel 2. El barrido deja tareas de nivel 1 con lo que se desvía |

**Un ajuste sobre una pantalla que aún no está al día con el manual no es nivel
1**: esa pantalla va a la cola de rediseño, y la tarea entra en su rediseño. Lo
urgente de verdad (un error, algo que bloquea al usuario) sí se arregla ya, como
ajuste mínimo.

---

## Nivel 2, paso a paso

| Paso | Quién | Deja |
|---|---|---|
| 0 · Inventario | tú | cuántas formas distintas conviven, con números |
| 1 · El hueco | tú, con el usuario | una frase |
| 2 · El manual | tú | `.proyecto/diseno.md` leído (o escrito) |
| 3 · La estructura | `disenador-interfaz` | trabajo, recorrido, jerarquía, estados, columnas y patrones nuevos |
| 4 · La piel | skill `marca` si hay `.proyecto/marca.yaml`; si no, `hallmark` | tokens, dentro del aspecto del manual |
| 5 · La maqueta | tú | `.proyecto/maquetas/<hueco>.html`, con el antes y las opciones |
| 6 · El usuario elige | **el usuario** | lo elegido y **lo rechazado, con su motivo**, en el manual |
| 7 · Construir | encargo (`encargar`) + `senior-dev` | el código |
| 8 · Verificar | `inspector-pantalla`, `usuario-novato`, `usuario-experto`, `auditor` y el usuario | hallazgos con evidencia |

**No te saltes el 0, el 2 ni el 6.** Son los que más caro salen cuando faltan.

## 0 · Inventario: buscar antes de dibujar

Antes de proponer nada, mira si eso **ya existe** y si está **en uso**:

```bash
grep -rl "<concepto>" <carpeta de componentes>
grep -rn "<Componente>" <carpeta del layout>   # ¿alguien lo pinta?
```

Y **cuenta el desorden**: cuántos sitios resuelven lo mismo de cada forma
(«errores: 13 con alert(), 64 en línea, 2 con aviso propio»). **Un número mide;
un adjetivo no.** Ese número es lo que convence de que el cambio vale. Muchas
veces la regla nueva es la forma que ya gana por mayoría, convertida en
obligación.

## 1 · Nombrar el hueco

«Tabla de pedidos con filtro por tienda y comparación de meses», no «que
se vea mejor». Sin un hueco con nombre no se puede elegir entre opciones.

Pregunta **ahora, no al final**: ¿se usa en el móvil? Si sí, la maqueta lleva
las dos vistas desde el principio. Si se pregunta al final, hay que rehacer
reglas que ya estaban aprobadas.

## 2 · El manual

Si el proyecto aún no tiene `.proyecto/diseno.md`, **para aquí**: primero el
manual (ver «El manual de la interfaz», arriba). Si ya hay muchas pantallas sin
él, eso es el **modo rescate**, más abajo.

Si lo tiene: léelo entero. Tu pantalla cabe en su marco, su interacción, su
vocabulario y su aspecto.

## 3 · La estructura: `disenador-interfaz`

Pásale el hueco, el inventario, `.proyecto/diseno.md` entero y `gustos/Gustos.md`.
Diseña **la tarea completa** (su recorrido de la sección 2 del manual), no la
pantalla suelta. Lo que necesite y el manual no tenga lo marca como **patrón
nuevo**: va a la maqueta como tal, decide el usuario en el paso 6 y se escribe
en el manual antes de construir. Para pantallas de datos, que use
[`references/patrones.md`](references/patrones.md), y sobre todo **la
clasificación de columnas** (identidad, decisión, detalle y comparación): ahí se
decide qué se ve siempre y qué se va a un panel lateral. Es el remedio directo
para lo amontonado.

## 4 · La piel

- Hay `.proyecto/marca.yaml`: skill **`marca`**. Sus colores y fuentes mandan.
- No lo hay: skill **`hallmark`**.

En los dos casos, **dentro** de la densidad y el espaciado de `diseno.md`.

## 5 · La maqueta: antes y después

Un HTML suelto en `.proyecto/maquetas/<hueco>.html`, sin depender de la app:

- **El «antes» es real.** Si hoy sale un `alert()` del navegador, el botón del
  «antes» lanza un `alert()`. Ver convence en un segundo; leer no.
- **El contenido de ejemplo sale del código**: nombres de campos, textos,
  estados y formatos de número reales. Inventado, puede proponer algo que el
  producto tiene prohibido.
  - **Nunca datos privados.** Si hacen falta cifras, que tengan la forma real
    pero no sean reales.
- **Propón de más.** Entre 3 y 6 opciones **de verdad distintas**: tabla o
  lista, panel lateral o fila que se despliega, filtros en línea o en un panel.
  Si dos opciones solo cambian el color o el radio de las esquinas, son la
  misma opción.
- Con los tokens del proyecto, y en escritorio y móvil si aplica.
- **Se reedita el mismo fichero**, para que comparar sea solo recargar.

**Para que el usuario la vea**: las maquetas quedan en `.proyecto/maquetas/` y
las capturas en `.proyecto/pantallas/`. Si el usuario no trabaja en la misma
máquina, déjaselas donde pueda abrirlas (una carpeta compartida, por ejemplo) y
dile dónde: abre el HTML con doble clic. **No le mandes capturas por el chat**: cada imagen gasta tokens.

## 6 · El usuario elige, probando

Espera a que elija. **Escribe lo elegido y lo rechazado, con su motivo**, en
la sección 11 de `.proyecto/diseno.md`, y los patrones nuevos que aprobó, en su
sección. Si no queda escrito, la sesión siguiente vuelve a proponer lo que ya
se descartó.

Lo que valga para otros proyectos, además, a `gustos-nuevos.md`: ver
«Aprender», abajo.

Muchas de las mejores reglas salen de un rechazo. Por ejemplo:
«sirve el movimiento que informa, no el que decora».

## 7 · Construir

**Mide el antes.** Si es un rediseño, pide a `usuario-experto` que cuente, en
la pantalla de hoy, los clics, las pantallas y las esperas del trabajo
principal. Al terminar lo vuelve a contar. «De 9 clics a 3» se puede comprobar;
«está mejor» no.

Antes de tocar nada, haz **la lista de todos los sitios donde aparece el
patrón**, con su número. Así la verificación es una lista que se marca, no una
búsqueda, y se nota si algo quedó fuera.

El encargo lleva la estructura del paso 3, la opción elegida en el 6 y
`.proyecto/diseno.md` **entero** (también en el nivel 1). Si trae código de
fuera, pasa antes por la puerta de adopción de
[`references/fuentes.md`](references/fuentes.md).

Orden de construcción:
1. semántica, datos, estados y teclado, sin depender de animaciones;
2. el layout de escritorio y el de móvil;
3. la respuesta inmediata a cada acción: pulsar, foco, selección, progreso y
   confirmación;
4. como mucho **una** transición, y solo si explica de dónde viene algo o a
   dónde va;
5. `prefers-reduced-motion`.

## 8 · Verificar donde vive de verdad

**La maqueta no demuestra que nada funcione**: es HTML suelto. Lo demuestra la
app real, abierta en el navegador:

| Agente | Mira |
|---|---|
| `inspector-pantalla` | si cumple el manual: marco, interacción, vocabulario, aspecto y estados |
| `usuario-novato` | si se puede terminar el trabajo sin que nadie lo explique |
| `usuario-experto` | cuánto cuesta repetirlo: clics, esperas y volumen |
| `auditor` | si los totales cuadran entre pantalla, exportación y base de datos |

**`usuario-novato` y `usuario-experto` dan el visto bueno** (usuario,
30-10-2026): ninguna pantalla nueva o cambiada se da por terminada sin el «sí»
de los dos. Corren **por pantalla**, no por tanda. Quien los llama les pasa **la
lista de lo que esa pantalla tiene que permitir** (las tareas de la sección 2
del manual que la cruzan, `que-hacemos.md` y la guía de usuario, si existe) y les levanta la app **dos veces: con datos de
muestra y con la base vacía**. Por qué: en un proyecto, tras 12 horas de front,
el usuario entró en el entorno de pruebas y vio que no se podía calcular, ni subir la plantilla,
ni modificar conceptos; ningún agente lo vio, porque lo que falta no se ve
mirando la pantalla y los datos de muestra lo tapaban.

**Y el usuario, en lo que importa** (el piloto del rescate, una pantalla nueva
de uso diario): dale 2 o 3 tareas del manual, que las haga sin ayuda y apunta
dónde dudó. Novato y experto filtran antes, para que él solo vea lo que ellos
no ven: son la misma IA que diseñó, con sus mismos puntos ciegos. Donde dudó se
trata como cualquier comentario suyo (ver «Aprender»).

**Mide el después** con el mismo recorrido del paso 7 y apunta las dos cifras en
`como-lo-hacemos.md`.

**Los tokens se comprueban con una prueba, no con la buena voluntad.** La
primera vez, copia `herramientas/tokens_sueltos.py` al proyecto (por ejemplo a
`tests/` o `scripts/`) y añádelo a las pruebas. Falla si hay colores o fuentes
escritos a mano fuera del fichero de tokens:

```
python3 tokens_sueltos.py <carpeta del código> --tokens <fichero de tokens>
```

Sin evidencia visible no hay «aprobado». Las miradas de prueba que se pueden
añadir están en [`references/miradas.md`](references/miradas.md).

---

## Modo rescate: una app con muchas pantallas y sin manual

**Cuándo:** el proyecto ya tiene muchas pantallas (más de 5 o 6), no tiene
manual o no se respeta, y el usuario las ve feas o inconsistentes. Nació en
un proyecto con 19 pantallas.

**La idea:** el trabajo pesado lo hace la IA; el usuario **reacciona a algo que
ya puede usar**. No se le pide que decida reglas sobre un inventario: no sabe
qué decir de «tanto mugrero», y no tiene por qué.

1. **Diagnóstico**, sin tocar código. Recorre todas las pantallas (la app
   abierta, no solo el código) y saca:
   - el **mapa**: el trabajo de cada pantalla y las tareas reales que las
     cruzan, con su recorrido y su número de pasos;
   - el **inventario** de cómo se resuelve hoy cada cosa de la sección 5 del
     manual, con números («guardar: 7 con botón abajo, 5 arriba, 3 al salir
     del campo»), y del vocabulario («versión» en 6, «ejecución» en 5);
   - lo que sobra o se repite: dos pantallas con el mismo trabajo, una tarea
     que obliga a saltar de un lado a otro.
2. **Manual, decidido por ti.** Escribe `.proyecto/diseno.md` completo. Donde
   hay varias formas, elige: la que gana por mayoría si es buena; si no, la
   mejor, con patrones probados (GOV.UK Design System para formularios y
   flujos; Airtable o Linear para tablas y edición) y dentro de los gustos del
   usuario. **No le preguntes**: es tu primera apuesta, y el piloto la corrige.
   Lo que el usuario fijó de antemano (por ejemplo, «el marco se queda») se
   respeta y se anota en el manual.
3. **Piloto: dos pantallas, a fondo.** Las dos que más usa (o las de más
   tareas pendientes). Rediseño de nivel 2 completo, construido y funcionando
   en una rama aparte, con datos de prueba. Novato y experto pasan antes de
   enseñárselas. Luego **el usuario entra y hace su trabajo normal en ellas**,
   y comenta con sus palabras. Cada comentario corrige **el manual**, no solo
   la pantalla (ver «Aprender», abajo). Se repite hasta que esas dos le gusten.
   **Por qué dos y no todas:** si el criterio está mal, se tira el trabajo de
   dos pantallas, no de veinte.
4. **Despliegue al resto**, en orden de uso y de tareas pendientes:
   - primero la **pasada de consistencia** en todas: mismo sitio para cada
     acción, mismos mensajes, mismos estados, mismo vocabulario. Mecánica y
     verificable contra el manual; quita la sensación de «cada pantalla es de
     una app distinta». Aquí se escriben las **pruebas automáticas** de las
     reglas que se puedan comprobar;
   - después, **rediseño de nivel 2** de las que lo necesiten, una a una. El
     usuario ya no elige criterio: revisa el resultado.

**Mientras dura:** las tareas pendientes de pantallas se juntan en el rediseño
de su pantalla (nada de parches sueltos sobre lo que se va a rehacer). Lo que no
toca pantallas sigue en paralelo.

**El rescate termina** cuando todas las pantallas están «al día con el manual»
en su sección 3. Desde ahí, niveles 1, 2 y 3 como cualquier proyecto.

---

## Aprender: el feedback del usuario vale para siempre

Cada comentario del usuario sobre una pantalla, venga de donde venga (`/diseno`,
el chat, al probar el piloto, al elegir una maqueta), se trata igual:

1. **Se apunta con sus palabras y su motivo**, donde le toca:
   - vale para este proyecto → sección 10 del manual (`.proyecto/diseno.md`);
   - vale para todos sus proyectos (un gusto, no un dato de este negocio) →
     además, a `.proyecto/gustos-nuevos.md`, que tú pasas de vez en cuando a
     `Gustos.md` (ver el formato abajo);
   - si dudas de cuál de los dos, pregúntale.
2. **Se arregla donde lo vio.**
3. **Se busca el mismo fallo en todas las demás pantallas** y se arregla
   también (o queda una tarea por pantalla, si es mucho). Un comentario
   arreglado solo donde se vio sigue roto en las demás.
4. **Si se puede comprobar con una prueba automática, se escribe** (en la suite
   del proyecto, p. ej. `tests/test_interfaz.py`), y la regla del manual dice
   «Se vigila: prueba …». Desde ahí, ninguna pantalla puede romperla sin que
   falle la suite.

**Cómo sube una regla:** *escrita* → *la mira el inspector* → *prueba
automática*. La primera vez basta escribirla; si el usuario la repite, o si se
rompió otra vez, sube un grado.

**Formato para `gustos-nuevos.md`:**

```
- **No gusta:** <qué, concreto>
  - Por qué: <sus palabras, no las tuyas>
  - Aplica a: <herramientas de datos / webs / móvil / todo>
  - Origen: <repo>, <fecha>
```

- Apunta solo lo que el usuario **dijo**, con su motivo. No conviertas en gusto
  lo que tú deduces.
- Si contradice algo de `Gustos.md`, apúntalo igual y dile: «esto cambia tu
  gusto X; queda la versión nueva». Él decide.

---

## Lo que no se repite

| No vuelvas a… | Porque |
|---|---|
| dibujar sin buscar en el código | lo que ibas a diseñar puede estar hecho |
| inventar el contenido de ejemplo | puede proponer algo que el producto prohíbe |
| dejar el móvil para el final | obliga a rehacer reglas aprobadas |
| ofrecer opciones que solo cambian el color | no son alternativas |
| proponer algo ya rechazado | está escrito, con su motivo |
| enseñar la maqueta como prueba de que funciona | no lo es; lo prueba el paso 8 |
| meter animación «para que se vea moderno» | más moderno es responder rápido y no perder el contexto |
| parchear una pantalla que está en la cola de rediseño | se trabaja dos veces: el parche y tirarlo |
| construir un patrón que no está en el manual sin que el usuario lo vea | así nace la inconsistencia, una pantalla a la vez |
| arreglar un comentario del usuario solo donde lo vio | el mismo fallo sigue en las demás pantallas |
| pedirle al usuario que decida sobre un inventario | no sabe qué decir de «tanto mugrero»; reacciona mejor a algo que ya puede usar |

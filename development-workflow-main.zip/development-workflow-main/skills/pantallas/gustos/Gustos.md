# Gustos de diseño

Lo que te gusta y lo que no en las pantallas, aprendido de proyectos
anteriores. **Las sesiones lo leen antes de proponer cualquier pantalla**:
parten de lo que te gusta y no te proponen lo que ya rechazaste.

**El hueco que cierra:** lo que rechazabas en una maqueta solo quedaba apuntado
en ese proyecto, y el siguiente volvía a proponértelo.

**Cómo crece:** cuando eliges entre opciones de una maqueta (paso 6 de la
skill `pantallas`), la sesión apunta tu motivo en `.proyecto/gustos-nuevos.md`
de su repo. De vez en cuando pasas esas entradas aquí, a «Recién recogidos»,
y desde ese momento valen para todos los proyectos. Cómo lo automatices
(un script que recorra tus repos, a mano al cerrar un proyecto) es cosa tuya.

**Tú mandas:**
- puedes **editar, mover o borrar** cualquier entrada desde aquí;
- lo que pase a «Reglas firmes» no se discute;
- lo de «Preferencias» es el punto de partida, y una maqueta puede traer **una**
  opción exploratoria que vaya contra una preferencia, marcada como tal, por si
  cambiaste de opinión.

**Formato de cada entrada:**

```
- **No gusta:** filas como tarjetas grandes en una tabla de datos
  - Por qué: no puedo escanear muchas a la vez
  - Aplica a: herramientas de datos
```

`Gusta` / `No gusta`. «Aplica a»: herramientas de datos, webs, móvil, todo…
Lo que vale para una herramienta de datos puede no valer para una web.

Lo que sigue son los gustos de quien escribió este método. Sirven de ejemplo;
bórralos y empieza con los tuyos, o quédate con los que compartas.

---

## Reglas firmes

<!-- Lo que nunca se discute. Muévelo aquí desde abajo cuando lo tengas claro. -->

## Preferencias

<!-- El punto de partida de cada propuesta. -->

## Recién recogidos

- **No gusta:** menú lateral ancho con texto en la barra izquierda, aunque se pueda colapsar
  - Por qué: le quita a la app el ancho que necesita la tabla. El menú no se usa todo el tiempo, así que no debe ocupar espacio fijo
  - Aplica a: herramientas de datos
- **Gusta:** navegación compacta (barra de iconos o menú arriba) que deja casi todo el ancho a los datos
  - Por qué: la pantalla es para ver muchas columnas a la vez
  - Aplica a: herramientas de datos
- **No gusta:** controles apilados uno por fila (un filtro solo en su renglón, y otro debajo igual)
  - Por qué: desperdicia el alto de la pantalla y empuja los datos hacia abajo. Hay que medir cuánto se ve sin desplazar y llenar cada renglón: varios filtros en la misma línea
  - Aplica a: herramientas de datos
- **Gusta:** diseñar pensando en el tamaño real de la pantalla: cuántas columnas y filas de datos caben a la vista
  - Por qué: en una herramienta de datos, el espacio que no muestra datos es espacio perdido
  - Aplica a: herramientas de datos
- **Gusta:** barra de iconos a la izquierda junto con un menú arriba, en vez de un menú lateral con texto
  - Por qué: «Quiero ambos barra izquierda y menu superior»; el espacio va para los datos
  - Aplica a: herramientas de datos
- **Gusta:** todos los controles de una tabla en un solo renglón, con los filtros sin etiqueta
  - Por qué: deja la primera fila de datos lo más arriba posible
  - Aplica a: herramientas de datos
- **No gusta:** elementos descuadrados en horizontal: algo que no está centrado en su propio hueco, o que no va alineado con los elementos de al lado (p. ej. un logo más ancho que la columna de iconos y corrido a un lado, o un botón más alto que el menú junto al que está)
  - Por qué: «cuando algo no está centrado en proporción con sí mismo o con otros elementos horizontalmente puede percibirse feo»
  - Aplica a: todo
- **Regla:** la barra de iconos de la izquierda y el menú de arriba son los mismos en todas las pantallas, y en cada maqueta
  - Por qué: «el menu izquierda y encima tiene que ser consistente en todas las pantallas»
  - Cómo se aplica: toda maqueta nueva parte del marco de navegación de la app, sin variarlo; solo cambia el contenido de la página
- **No gusta:** columnas o paneles vecinos cuyo contenido empieza a distinta altura (p. ej. una lista que empieza más abajo que la de al lado porque lleva filtros encima)
  - Por qué: «hay que mantener armonía visual … se ve como desfasado porque las tablas empiezan en diferente nivel»
  - Cómo se aplica: en paneles lado a lado, las cabeceras y el arranque de las tablas comparten la misma línea horizontal; si un panel lleva filtros o un total grande, el otro reserva ese alto o los filtros se suben a la barra común. Se mide la `y` de cada tabla en la maqueta: deben coincidir
  - Aplica a: todo
- **Gusta:** construir una fórmula arrastrando y soltando piezas (conceptos, operadores), no escribiéndola en un cuadro de texto
  - Por qué: «necesitamos un editor muy fancy… no un textbox»
  - Aplica a: herramientas de datos
- **No gusta:** los caracteres «→» y «·» en textos de pantalla, botones, avisos o informes
  - Por qué: se escribe con palabras: «de A a B», «A, B», o una coma
  - Aplica a: todo
- **No gusta:** para elegir con qué datos calcular, una lista de borradores con casillas
  - Por qué: se prefiere una sección por cada cosa que se puede usar, y dentro las opciones que hay (la actual o un borrador)
  - Aplica a: herramientas de datos
- **Gusta:** explicar un cálculo en orden, del paso 1 con los datos de partida hasta el último paso con el resultado, no de la cifra hacia atrás
  - Por qué: «lo quiero desde el paso 1 hasta el paso final»
  - Aplica a: herramientas de datos
- **No gusta:** textos de pantalla inventados o de chat
  - Por qué: «es una app no un mensaje de whatsapp». Cada etiqueta dice el dato con el nombre que usa quien trabaja con él, y cada botón lo que hace
  - Aplica a: todo
- **No gusta:** etiqueta y valor con el mismo peso («Nombre: VALOR» todo igual)
  - Por qué: «cada cosa debería tener negritas para que se distinga el campo»
  - Aplica a: fichas y formularios
- **No gusta:** controles de la misma franja a alturas o anchos distintos
  - Por qué: «debería estar todo igual a la misma altura para que haya consistencia visual»
  - Aplica a: todo
- **No gusta:** datos de un mismo concepto repartidos en secciones que no se distinguen («Datos» y «Más ajustes») y que encima no se pueden editar
  - Por qué: «¿para qué queremos dos secciones, y por qué no se pueden editar?»
  - Aplica a: fichas
- **No gusta:** letras pegadas al borde de su caja
  - Por qué: «debe de haber suficiente padding»
  - Aplica a: todo

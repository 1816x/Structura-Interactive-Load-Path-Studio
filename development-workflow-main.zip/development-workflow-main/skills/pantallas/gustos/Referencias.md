# Referencias de diseño

Ejemplos que te sirven de modelo, descritos en texto, y las fuentes de componentes. Las sesiones leen esta
nota en los pasos 3 a 5 de la skill `pantallas`, después de [[Gustos]].

**El hueco que cierra:** una sesión sin referencias acaba haciendo lo de
siempre. Van **en texto, no en capturas**: una imagen la interpreta la IA a su
manera, y una frase tuya con su motivo no (decisión del usuario, 25-10-2026).

## Tus ejemplos

Apps o páginas que te sirven de modelo, **siempre con qué te gusta de ellas en
palabras**: la sesión no las abre para «interpretar» su estilo, se guía por lo
que tú escribes. Si quieres que la mire, dilo en la línea.

- <app o url>: qué te gusta, en concreto («la tabla deja fija la primera
  columna y el detalle sale a la derecha»)

## Fuentes de componentes

Catálogos de componentes (ver `references/fuentes.md`, revisado el 27-08-2026). **La sesión no los consulta
cada vez:** solo abre la web cuando va a traer un componente concreto, porque
cambian y la licencia hay que leerla al día. Antes de traer nada pasa la puerta
de adopción de `references/fuentes.md` de la skill.

Casi todos son para **React y Tailwind**. En Streamlit no sirven.

| | Para qué | Licencia, a verificar al usarla |
|---|---|---|
| [shadcn/ui](https://ui.shadcn.com) | base accesible: foco, teclado, estados. No es una estética obligatoria | uso libre |
| [Beautiful UI](https://beautifului.dev) | estados de producto sobrios: carga, tareas, filtros, búsqueda, registros | [su página de licencia](https://www.beautifului.dev/license) |
| [Bklit UI](https://bklit.com) | gráficos: línea, barras, mapa de calor, Sankey, mapas | MIT; Bklit Studio es propietario |
| [Kokonut UI](https://kokonutui.com) | componentes limpios sobre shadcn | MIT; la versión Pro aparte |
| [beUI](https://beui.dev) | tablas ricas, paneles, menús, avisos | con reservas: revisar el repo |
| [Motion.dev](https://motion.dev) | motor de animación (no catálogo) | MIT; Motion+ de pago |
| [Transitions.dev](https://transitions.dev) | recetas de transiciones en CSS | fragmentos sí, la colección no |
| [Rare UI](https://rareui.com) | microinteracciones llamativas: uno o dos acentos como mucho | con reservas |
| [React Bits](https://reactbits.dev) | texto animado, fondos, efectos | MIT + Commons Clause |
| [21st.dev](https://21st.dev) | buscador comunitario: lleva al autor original | cada componente la suya |
| [GetDesign.md](https://getdesign.md) | análisis del sistema de diseño de otras marcas | inspiración, no copiar |

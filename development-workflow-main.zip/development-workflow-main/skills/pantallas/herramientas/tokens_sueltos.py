#!/usr/bin/env python3
"""Falla si hay colores o fuentes escritos a mano fuera del fichero de tokens.

Qué hueco cierra: «los componentes solo usan tokens» era una instrucción, y una
instrucción se olvida. Como prueba, el olvido rompe las pruebas.

    python3 tokens_sueltos.py <carpeta> --tokens <fichero> [--tokens <otro>]
                              [--ignorar <ruta>]...

Busca en .css .scss .html .js .jsx .ts .tsx .vue .svelte .py .toml:
  - colores: #abc, #aabbcc, #aabbccdd, rgb(…), rgba(…), hsl(…)
  - fuentes: font-family: … y fontFamily: … que no usen var(--…)
Una línea con «tokens-ok» en un comentario queda exenta (para la excepción
justificada). Sale con 1 y la lista si encuentra algo; con 0 si no.
"""
import argparse
import os
import re
import sys

EXT = {".css", ".scss", ".html", ".js", ".jsx", ".ts", ".tsx", ".vue", ".svelte", ".py", ".toml"}
SALTAR = {"node_modules", ".git", ".venv", "venv", "dist", "build", "__pycache__", ".proyecto"}
COLOR = re.compile(r"(?<![\w&])#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})\b|\b(?:rgba?|hsla?)\(")
FUENTE = re.compile(r"(font-family|fontFamily)\s*[:=]\s*(?!\s*['\"]?var\()", re.I)


def main():
    a = argparse.ArgumentParser()
    a.add_argument("carpeta")
    a.add_argument("--tokens", action="append", default=[])
    a.add_argument("--ignorar", action="append", default=[])
    o = a.parse_args()
    exentos = {os.path.abspath(t) for t in o.tokens + o.ignorar}
    yo = os.path.abspath(__file__)
    malos = []
    for raiz, dirs, ficheros in os.walk(o.carpeta):
        dirs[:] = [d for d in dirs if d not in SALTAR]
        for f in ficheros:
            p = os.path.abspath(os.path.join(raiz, f))
            if os.path.splitext(f)[1] not in EXT or p == yo:
                continue
            if any(p == e or p.startswith(e + os.sep) for e in exentos):
                continue
            try:
                lineas = open(p, encoding="utf-8", errors="ignore").read().splitlines()
            except OSError:
                continue
            for n, l in enumerate(lineas, 1):
                if "tokens-ok" in l:
                    continue
                if COLOR.search(l) or FUENTE.search(l):
                    malos.append(f"{os.path.relpath(p)}:{n}: {l.strip()[:100]}")
    if malos:
        print(f"✗ {len(malos)} color(es) o fuente(s) fuera de los tokens:")
        print("\n".join(malos))
        print("Usa una variable de tokens, o marca la línea con «tokens-ok» y el motivo.")
        return 1
    print("✓ ningún color ni fuente fuera de los tokens")
    return 0


if __name__ == "__main__":
    sys.exit(main())

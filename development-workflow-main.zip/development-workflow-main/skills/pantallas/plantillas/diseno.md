# Manual de la interfaz de <proyecto>

Cómo es y cómo se comporta la interfaz de este proyecto. **Todo el que toque una
pantalla lo lee antes**: `disenador-interfaz` diseña dentro de él,
`inspector-pantalla` mide contra él, y cada encargo de front lo lleva.

Lo que se aparte de él es un hallazgo. Si hace falta algo que no está aquí, es un
**patrón nuevo**: se propone, decide el usuario y se añade aquí **antes** de
construirlo.

---

## 1 · Para quién y cómo se usa

- **Quién:** <persona concreta y su trabajo>
- **Cada cuánto:** <a diario / semanal / de vez en cuando>
- **Volumen típico:** <p. ej. 20 tiendas, 500 pedidos al día, 3 meses abiertos>
- **Dispositivo:** <escritorio / también móvil / solo móvil>

## 2 · Las tareas

Las 5 o 6 cosas que esa persona viene a hacer, **con sus palabras**, y su
recorrido de pantalla en pantalla. Se diseña para que estos recorridos sean
cortos y obvios; una pantalla bonita en un recorrido absurdo sigue siendo mala.

| Tarea | Recorrido hoy | Pasos |
|---|---|---|
| <«cerrar los pedidos del día»> | <Inicio → Pedidos (filtro tienda) → Revisar → Cerrar día> | <4> |

## 3 · Las pantallas

Una pantalla, un trabajo. Si dos tienen el mismo trabajo, sobra una; si una no
cabe en una frase, son dos.

| Pantalla | Su trabajo, en una frase | Tareas que la cruzan | Estado |
|---|---|---|---|
| <Fórmulas y valores> | <«consultar y corregir el valor de un concepto»> | <1, 3> | <rediseñada · al día con el manual · pendiente> |

## 4 · El marco

Lo que rodea a todas las pantallas y no cambia entre ellas.

- **Navegación (barra lateral):** <qué secciones, en qué orden, agrupadas cómo>
- **Barra superior:** <qué lleva: dónde estás, el contexto activo (versión,
  país…), las acciones globales>
- **Lo que el marco no lleva:** <…>

## 5 · Interacción

Una sola forma para cada cosa, en toda la app.

- **La acción principal:** <dónde vive (p. ej. arriba a la derecha de la
  pantalla) y cómo se ve>. Una por pantalla.
- **Acciones de una fila:** <al final de la fila / al seleccionarla / en su
  detalle>
- **Ver el detalle de un elemento:** <panel lateral / página propia / fila que
  se despliega>
- **Editar y guardar:** <en la tabla o en un formulario; se guarda con botón o
  solo; qué pasa al salir con cambios sin guardar>
- **Confirmar y deshacer:** <qué pide confirmación (solo lo que no se deshace) y
  cómo; qué se puede deshacer>
- **Filtrar y buscar:** <dónde van los filtros; si se recuerdan al cambiar de
  pantalla; cómo se ve que hay un filtro puesto>
- **Lo largo (cálculos, cargas):** <cómo se ve que está trabajando y cuánto
  falta; si se puede seguir haciendo otra cosa>
- **Mensajes:** <éxito: …; aviso: …; error: dónde sale, qué dice (qué pasó y
  qué hacer, nunca solo «error»)>
- **Estados:** vacío <qué se ve y cómo se empieza> · cargando <…> · error <…> ·
  sin permiso <se oculta o se explica>
- **Números y fechas:** <formato, decimales, moneda, a la derecha>

## 6 · Vocabulario

Un nombre por concepto, igual en títulos, botones, columnas y mensajes.

| Concepto | Se dice | No se dice |
|---|---|---|
| <una corrida del cálculo> | <ejecución> | <versión, corrida, run> |

## 7 · Aspecto

### Densidad

Elige una y bórrala del resto:

| | Alto de fila | Letra de tabla | Padding de celda | Para |
|---|---|---|---|---|
| **compacta** | 32 px | 13–14 px | 4 × 8 px | herramienta diaria con mucho dato |
| **normal** | 40 px | 14–15 px | 8 × 12 px | gestión del día a día |
| **cómoda** | 48 px | 16 px | 12 × 16 px | lectura, uso ocasional, móvil |

Elegida: **<…>**, porque <…>.

### Espaciado

- **Unidad:** 4 px. Todo es múltiplo: 4, 8, 12, 16, 24, 32 y 48.
- Entre secciones: <…> · dentro de un grupo: <…> · entre etiqueta y campo: <…>
- Ancho máximo del texto corrido: 70 caracteres.

### Tipografía

- Familias y pesos: <de la marca, o de hallmark>
- Escala (px): <p. ej. 12 · 14 · 16 · 20 · 24 · 32>
- Números: alineados a la derecha, con cifras de ancho fijo
  (`tabular-nums`), y siempre con el mismo número de decimales en una columna.

### Tokens y componentes

- **Tokens:** <ruta del fichero>. Marca: <preset de `.proyecto/marca.yaml`, o
  «ninguna»>. En los componentes no se escribe ningún color, fuente ni tamaño a
  mano.
- **Familia de componentes:** <una sola: p. ej. los nativos de Streamlit>

## 8 · Fronteras del producto

Lo que esta app **no** hace ni enseña, para que ninguna maqueta lo proponga:
- <…>

## 9 · Móvil

<no se usa / qué cambia: lista en vez de tabla, filtros en panel inferior…>

## 10 · Reglas aprendidas

Lo que el usuario dijo (con `/diseno`, al probar una pantalla o al elegir una
maqueta) y vale para todo este proyecto. **Con sus palabras y su motivo.** Cada
regla dice cómo se vigila; cuanto más se repite un comentario, más sube:
*escrita* → *la mira el inspector* → *prueba automática*.

```
- **<la regla, concreta>**
  - Por qué: <sus palabras>
  - Se vigila: <escrita / inspector / prueba: tests/test_interfaz.py::…>
  - Origen: <pantalla, fecha>
```

## 11 · Elegido y rechazado

Cada decisión de diseño que tomó el usuario, **con lo que rechazó y por qué**.
Si no queda aquí, una sesión futura le vuelve a proponer lo descartado.

```
- <fecha> · <pantalla o regla>: elegido <…>; rechazado <…> porque <sus palabras>
```

# Fuentes y adopción responsable

> Antes de instalar algo de estas fuentes, revísalo a mano: lee el repositorio, su licencia y
> sus scripts de instalación, y pásalo por `paranoico` antes de instalar.

Las URLs y licencias cambian. Esta guía define el rol de cada fuente; antes de copiar código,
verifica el componente y la licencia vigentes en la fuente oficial.

Última revisión documental de estas fuentes: **2026-08-27**.

## Las capas no se mezclan

| Capa | Fuente típica | Qué decide |
|---|---|---|
| Dirección visual | `DESIGN.md`, GetDesign.md | tokens, tipografía, geometría y carácter |
| Descubrimiento | 21st.dev | qué candidatos existen y quién los publicó |
| Motor | CSS native, Motion.dev | cómo se ejecuta el movimiento |
| Componente | Beautiful UI, beUI, Kokonut UI, Bklit, React Bits, Rare UI | estructura y comportamiento concreto |
| Pulido | Transitions.dev | timing, transición y tokens coherentes |

No adoptes el sistema visual del catálogo, el runtime de un segundo catálogo y los primitivos de un
tercero sin nombrar cada capa. Una recomendación útil dice cuál entra y cuál no.

## Repertorio principal

### Beautiful UI — https://beautifului.dev

- Mejor para estados de producto e IA sobrios: thinking, loading, approval, tasks, records, diff,
  filtros, búsqueda, sidebar e insight cards.
- Úsalo cuando el movimiento debe explicar qué está pasando sin dominar la pantalla.
- Si no hay repo oficial enlazado desde el componente, trátalo como referencia o copy-paste
  manual permitido por sus términos; no inventes una procedencia GitHub.
- Verifica la [licencia oficial](https://www.beautifului.dev/license) y atribución actuales antes
  de copiar.

### Motion.dev — https://motion.dev

- Es un **motor**, no una estética ni un catálogo de producto. Úsalo para layout animation,
  gestos cross-device, springs, keyframes interrumpibles, scroll y orquestación ligada al estado.
- Para hover de color, fade o reveal autocontenido, CSS sigue siendo más ligero.
- El paquete abierto `motion` usa [licencia MIT](https://github.com/motiondivision/motion/blob/main/packages/motion/LICENSE.md);
  Motion+ y sus ejemplos/componentes premium tienen términos comerciales separados. No confundas
  la licencia del runtime con la del ejemplo.
- Importa sólo las capacidades requeridas, revisa bundle y usa `useReducedMotion` o equivalente.

### Bklit UI — https://bklit.com

- Especialista en gráficas animadas: line, area, bar, live line, composed, scatter, candlestick,
  pie, ring, radar, gauge, heatmap, funnel, Sankey y choropleth.
- El registry `@bklit` entrega código composable; el paquete de charts del
  [repo oficial](https://github.com/bklit/bklit-ui) es MIT. **Bklit Studio es propietario** y no
  puede reutilizarse o redistribuirse como si fuera parte MIT.
- Puede agregar Motion, Visx, D3 y medición de layout. Revisa las dependencias del chart exacto;
  no adoptes toda la suite por una sparkline.
- En mobile reduce ticks, series, leyendas y controles; conserva el dato y el tooltip vía tap/focus.

### beUI — https://beui.dev

- Mejor para componentes React expresivos: tablas ricas, botones reactivos, sidebars, tabs,
  morphing modals, drawers, sheets, toasts y superficies animadas.
- Suele implicar Motion/Framer Motion, Tailwind y dependencias auxiliares. Inspecciona el árbol de
  dependencias y cherry-pickea sólo el patrón necesario.
- Estado de adopción conocido: **USE WITH CAVEATS**. Vuelve a revisar a mano (licencia y scripts) el
  repo enlazado actualmente antes de instalar o ejecutar scripts.

### Kokonut UI — https://kokonutui.com

- Fuente limpia y moderna para botones, cards, navegación, AI prompt, loaders y componentes de
  producto construidos con React, Tailwind, shadcn/ui y Motion.
- El [repo abierto](https://github.com/kokonut-labs/kokonutui) declara MIT; Kokonut UI Pro es una
  oferta distinta y debe verificarse bajo sus propios términos.
- Instala sólo el item requerido del registry `@kokonutui`. Revisa el dry-run porque un componente
  puede incorporar Motion, nuevos primitivos o efectos como particles/liquid glass.
- Prefiérelo cuando la composición ya resuelve una interacción. No lo uses para llenar cada hueco
  sólo porque sus piezas comparten catálogo.

### Rare UI — https://rareui.com

- Mejor para firmas visuales y microinteracciones poco comunes, no como base completa del producto.
- Limita cada adopción a uno o dos acentos con hueco declarado y fallback sobrio.
- Revisa especialmente Canvas/WebGL, filtros, listeners globales y trabajo por frame.
- Estado de adopción conocido: **USE WITH CAVEATS**; veta el repo exacto y licencia actual.

### React Bits — https://reactbits.dev

- Mejor para texto animado, backgrounds, cursores, galerías, listas y acentos interactivos. Ofrece
  variantes JS/TS con CSS o Tailwind y entradas por shadcn/jsrepo.
- El [repo oficial](https://github.com/DavidHDev/react-bits) declara **MIT + Commons Clause**, no
  MIT puro: confirma que el uso y la redistribución previstos cumplen la restricción de no vender
  la colección como producto.
- React Bits Pro tiene licencia y contenido separados, incluidos bloques de app y templates.
- Audita cada efecto: 3D, partículas, shaders, listeners de puntero y trabajo por frame necesitan
  fallback mobile, reduced motion y presupuesto de GPU.

### Transitions.dev — https://transitions.dev

- Mejor para patrones portables de transición, microinteracción y CSS moderno.
- Úsalo como vocabulario de movimiento y como fuente de snippets puntuales.
- Sus snippets pueden usarse dentro de productos conforme a sus términos vigentes, pero no copies
  la colección completa ni la redistribuyas como otro kit, catálogo o skill.
- Para revisar motion existente, prefiere primero los comandos read-only del skill:
  `transitions review`, `transitions refine` y `transitions polish`.
- El skill/snippets, Pro y **Refine live** son superficies distintas. Para
  `npx transitions-refine live` lee `refine-safety.md`.

### 21st.dev — https://21st.dev

- Es un agregador y registry comunitario, no una librería con calidad, autor o licencia únicos.
  Úsalo para buscar por hueco, comparar previews y llegar a la página/repo del autor.
- Registra el link directo del componente, autor y licencia individual. Inspecciona archivos,
  dependencias y colisiones de nombres antes de ejecutar el comando shadcn.
- Sus [términos](https://21st.dev/terms) reservan previews, media, curation y metadata, prohíben
  scraping no autorizado y limitan redistribución. No copies su catálogo dentro de este skill ni
  uses sus demos como assets.
- Si el componente existe en el registry oficial del autor, prefiere esa fuente para adopción.

### GetDesign.md — https://getdesign.md

- Es una colección de análisis `DESIGN.md`: dirección visual, tokens, tipografía, geometría,
  componentes, motion y estrategia responsive. **No es una librería de animaciones.**
- Úsalo cuando el proyecto carece de lenguaje visual o el usuario elige explícitamente una
  referencia. Una sola referencia primaria; combina rasgos sólo con una decisión documentada.
- Sus análisis son inspiración independiente, no design systems oficiales. No copies logos,
  assets, textos ni trade dress de la marca observada.
- La CLI `getdesign` puede escribir `DESIGN.md`; inspecciónala antes de ejecutar, usa `--out` para
  comparar y nunca `--force` sin autorización. Los starter kits pagados tienen
  [restricciones de redistribución](https://getdesign.md/terms) distintas del paquete CLI MIT.

### shadcn/ui — https://ui.shadcn.com

- Mejor como referencia de semántica, estados, foco, teclado y composición sobre Radix.
- No es una dirección visual obligatoria. Cambia geometría, densidad, jerarquía, tokens y motion
  según el producto; no apiles cards redondeadas por inercia.
- Estado de adopción conocido: **USE** para el repo oficial, verificando igualmente el componente
  y versión usados.

## Puerta de adopción

Antes de traer código externo:

1. Abre el link directo del componente y su preview.
2. Identifica autor, modelo (copy-paste, registry o dependencia), licencia y repo exacto.
3. Distingue licencia del código, assets, preview, plan Pro y herramienta/Studio; pueden diferir.
4. Si es repo público no conocido o cambió desde la última revisión, revísalo a mano (licencia y scripts de instalación) y pásalo por `paranoico`.
5. Inspecciona código y archivos que escribiría; usa `view` o `--dry-run` si existen.
6. Revisa dependencias, scripts de instalación, postinstall, permisos, red y telemetría.
7. Confirma compatibilidad con la familia de primitivos y stack del proyecto.
8. Re-viste con tokens locales; elimina colores, radios, shadows y fuentes del vendor.
9. Implementa reduced motion, mobile/touch y fallback antes de declarar terminado.
10. Revisa el diff, package manifest y lockfile; ejecuta build, tipos, pruebas y QA visual.
11. Registra fuente, autor, licencia, fecha, cambios y motivo para reemplazarlo en el futuro.

## Señales para rechazar o construir original

- licencia inexistente, ambigua o incompatible;
- instalador remoto ejecutado con pipe al shell;
- scripts ofuscados, postinstall injustificado o dependencias desproporcionadas;
- segunda familia de primitivos sólo para un efecto;
- componente que depende de hover para una acción necesaria;
- mobile tratado como escala reducida del desktop;
- animación que dificulta lectura, foco, scroll o rendimiento;
- copiar una colección completa cuando sólo se necesita una mecánica.

Cuando ninguna opción pasa el filtro, construye el patrón original y decláralo como original.

# Miradas de prueba

Diez formas de usar la app para encontrar fallos. Sirven para buscar casos de prueba: **no
demuestran** que una persona real la entienda o la prefiera.

**Se prueba la app abierta, no el código.** Primero se usa como la usaría alguien. Cuando sale un
fallo que se puede reproducir, se mira el código en un paso aparte. Encontrar y arreglar van en
tareas distintas, para que el arreglo no borre la prueba de que fallaba.

| # | Mirada | Qué busca | Quién la tiene aquí |
|---|---|---|---|
| 1 | Primera vez | terminar sin instrucciones; dudas, vueltas, jerga | `usuario-novato` |
| 2 | Poco contexto | etiquetas y consecuencias claras, sin abreviaturas sin explicar | `usuario-novato` |
| 3 | Impaciente | una acción principal clara; qué botones, pestañas o filtros sobran | `disenador-interfaz` (antes) · `usuario-experto` (después) |
| 4 | Teclado y accesibilidad | foco visible y en orden, etiquetas, zoom, contraste, sin depender del hover | `inspector-pantalla` |
| 5 | Móvil | pantalla estrecha, botones de 44–48 px, teclado virtual, una mano | `inspector-pantalla` a 360 px |
| 6 | Errores y recuperación | entrada inválida, vacío, red lenta, cancelar, reintentar, deshacer | `inspector-pantalla` + `usuario-novato` |
| 7 | Uso intensivo | repetir, doble clic, atrás y recargar, muchas filas, filtros rápidos | `usuario-experto` |
| 8 | Rol equivocado | URL directa, acciones sin permiso, ocultas o desactivadas | `paranoico` |
| 9 | Desconfía de los datos | totales, fechas y moneda, filtros que se reinician, paginación, exportación, duplicados | `auditor` |
| 10 | Crítico visual | jerarquía, densidad, exceso de texto, componentes mezclados, animación sin propósito | `inspector-pantalla` |

## Estados que se cubren

Inicial, vacío, con datos, cargando, éxito, error, entrada inválida, extremo (muchísimas filas,
textos larguísimos), sin permiso, red lenta, acción repetida, sesión caducada y fallo a medias. No
todos aplican siempre: se eligen los del recorrido principal y los de riesgo, y se dice cuáles se
dejaron fuera.

## Cómo se anota cada caso

**Pantalla · mirada · acción · resultado esperado · resultado visto · evidencia.** La evidencia es
una captura en `.proyecto/pantallas/` o lo que dijo la consola.

Resultado: **aprobado · falla · a medias · bloqueado · sin probar**. «Sin probar», «a medias» y
«bloqueado» **no son aprobados**.

## Límites

- Solo navegación de lectura y formularios que se pueden deshacer. Nada que escriba datos reales
  sin permiso del usuario.
- **Nunca con datos privados del usuario.** Si la app los carga, se prueba con datos inventados.

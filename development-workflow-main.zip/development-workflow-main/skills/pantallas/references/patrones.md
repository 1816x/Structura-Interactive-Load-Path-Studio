# Patrones por hueco

> Las columnas de «Candidatos» citan catálogos de
> componentes. Antes de traer código de alguno, pasa por [fuentes.md](fuentes.md).


Entra por la tarea que el usuario necesita resolver. La columna “mobile” describe una
**transformación de interacción**, no un breakpoint cosmético.

## Producto y datos

| Hueco | Desktop | Mobile | Movimiento útil | Candidatos iniciales |
|---|---|---|---|---|
| Tabla de datos | Tabla densa, header sticky, selección y detalles laterales | Lista o tarjetas con campos prioritarios; detalle expandible o sheet | Reordenar filas con continuidad, revelar detalle, confirmar actualización sin mover toda la vista | beUI para tabla rica; Beautiful UI para records/diff/filter; shadcn/TanStack sólo como base funcional |
| Comparación por columnas | Tabla o matriz alineada | Scroll horizontal deliberado con primera columna fija y pista visual | Indicador de posición y cambios de columna; nada de auto-scroll sorpresivo | Base accesible propia + CSS native; shadcn/TanStack como motor opcional |
| Filtros | Barra inline, chips y conteo inmediato | Botón con conteo → bottom sheet; chips aplicados permanecen visibles | Sheet con continuidad, chip entra/sale, resultados actualizan sin flash | beUI para paneles/morph; Transitions.dev para sheet/chips; Beautiful UI para filter table |
| Orden y vistas | Segmented control, columnas o command menu | Control compacto o menú anclado al pulgar | Indicador activo compartido; contenido cruza en dirección coherente | Transitions.dev; CSS native; primitivo accesible del proyecto |
| Edición de fila | Inline o panel lateral persistente | Pantalla o sheet con acciones sticky | La fila origina el panel; éxito vuelve al mismo registro | beUI morphing panels; Transitions.dev; shadcn sólo para diálogo/foco |
| Serie o KPI temporal | Gráfica completa con tooltip, rango y comparación | Resumen + gráfica simplificada; menos ticks y controles táctiles | Tween del dominio al filtrar; reveal inicial una sola vez | Bklit para charts composables; Motion.dev sólo si el patrón requiere física/layout |
| Funnel, Sankey o mapa | Visualización explorable con leyenda y detalle | Resumen priorizado o vista dedicada; no comprimir toda la geometría | Entrada por fases y hover con equivalente tap/focus | Bklit; verificar peso de Visx/D3 y el costo del tipo exacto |

### Regla para tablas móviles

Primero clasifica las columnas:

- **identidad:** siempre visible;
- **decisión:** visible si ayuda a actuar;
- **detalle:** va al expandible/sheet;
- **comparación:** conserva tabla y permite scroll controlado.

No conviertas automáticamente cada fila en una card enorme. Si el usuario necesita escanear
muchos registros, usa una lista compacta con jerarquía tipográfica y detalle progresivo.

### La misma regla en escritorio: el remedio de lo «amontonado» (añadido nuestro)

Una tabla amontonada casi siempre enseña **todas** las columnas a la vez. Clasifícalas igual:

- **identidad** (qué fila es: país, posición): fija a la izquierda, siempre visible;
- **decisión** (lo que se mira para actuar: total, variación, estado): visible, junto a la
  identidad, con los números alineados a la derecha;
- **detalle**: fuera de la tabla, en un panel lateral al seleccionar la fila, o en columnas
  que el usuario puede mostrar;
- **comparación** (versión A frente a B, mes frente a mes): columnas pareadas con la diferencia
  al lado, no en dos tablas.

Y además:

- la cabecera, fija al hacer scroll;
- **un** nivel de agrupación como mucho (país → posiciones), plegable, con el subtotal en la fila
  del grupo;
- los filtros en una barra encima, con el número de resultados y lo aplicado siempre visible;
- **un** botón principal por pantalla. El resto, como texto o en un menú;
- densidad **compacta** (ver `diseno.md`) si es una herramienta de uso diario. Lo amontonado
  no se arregla con más aire: se arregla **quitando columnas de la vista**.

## Controles y navegación

| Hueco | Desktop | Mobile | Movimiento útil | Candidatos iniciales |
|---|---|---|---|---|
| Botón primario | Hover sutil, press, loading estable | Target de 44–48 px, press/tap visible, sin depender de hover | `scale` leve al presionar; label/icono transforman; ancho no salta en loading | Transitions.dev y CSS native; Kokonut UI o beUI para una composición más expresiva |
| Botón con proceso | Texto + progreso o estado | Igual, con feedback inmediato al tap | idle → loading → éxito/error preservando identidad | Beautiful UI para estados de tarea/IA; Transitions.dev para morph |
| Sidebar | Rail expandible, labels y preview opcional | Bottom nav para destinos principales o sheet para navegación extensa | Indicador activo compartido; expansión con contenido estable | beUI o Kokonut UI; Rare UI para acento; shadcn sólo como estructura accesible |
| Tabs | Tabs horizontales o verticales | Scroll de tabs, segmented compacto o selector | Indicador activo via shared layout; dirección sigue navegación | beUI, Kokonut UI, Transitions.dev o CSS native |
| Command/search | Overlay centrado o panel contextual | Full-screen sheet con teclado y acción de cerrar clara | Campo conserva foco; resultados aparecen en stagger muy corto | Beautiful UI para search; base accesible del proyecto |

## Paneles, overlays y feedback

| Hueco | Desktop | Mobile | Movimiento útil | Candidatos iniciales |
|---|---|---|---|---|
| Panel de detalle | Panel lateral, resizable si aporta | Bottom sheet o pantalla completa | Shared element desde el disparador; cierre vuelve al origen | beUI morphing modal/drawer; Transitions.dev; CSS View Transitions |
| Dialog de decisión | Modal centrado, foco atrapado | Sheet o full-screen si contiene formulario largo | Entrada corta; acción destructiva sin espectáculo | Primitivo accesible del proyecto + Transitions.dev |
| Popover | Anclado al control | Sheet si la superficie o teclado lo exige | Escala/origen desde anchor; reposiciona sin salto | beUI/Transitions.dev sobre el primitivo existente |
| Toast | Esquina con pila limitada | Sobre safe area inferior y fuera de navegación | Pila reacomoda; swipe sólo con alternativa accesible | beUI; Transitions.dev; sistema de toast existente |
| Progreso largo | Estado inline + detalle opcional | Estado sticky y recuperable | Progreso continuo, etapas, final claro; nunca spinner eterno | Beautiful UI y beUI para task/agent states |
| Empty/error/success | En contexto, con acción clara | Igual, priorizando lectura y tap | Transición entre estados sin borrar contexto | Beautiful UI; Transitions.dev; CSS native |

## IA, páginas y acentos

| Hueco | Uso | Movimiento útil | Fuente preferida | Límite |
|---|---|---|---|---|
| Thinking/tool calls | Explicar actividad y progreso real | Stagger corto, streaming legible, estados que colapsan al terminar | Beautiful UI o beUI | No simular trabajo que no existe |
| Streaming content | Mostrar llegada progresiva | Reveal por bloques o texto, scroll controlado | Beautiful UI / Transitions.dev | No secuestrar el scroll del usuario |
| Cambio de página | Conservar orientación | View Transition/shared layout entre elementos equivalentes | CSS native / Transitions.dev / Motion.dev | Debe degradar a navegación inmediata |
| Scroll reveal | Jerarquizar contenido editorial | Una coreografía por sección, no por cada nodo | CSS native / Transitions.dev | Evitar en tablas y tareas repetitivas |
| Texto animado | Jerarquizar un mensaje corto o estado | Reveal breve, legible y sin loop continuo | React Bits o Transitions.dev | No usar en labels, tablas ni lectura larga |
| Fondo shader/orb/grid | Momento de marca o estado ambiental | Reacción lenta, desconectada del input crítico | React Bits, beUI o Rare UI | Acento acotado; presupuesto de GPU y fallback estático |

## Cómo elegir la fuente

- **Dirección visual y tokens:** el `DESIGN.md` del proyecto; GetDesign.md sólo si hace falta una
  referencia nueva y explícita.
- **Descubrimiento amplio:** 21st.dev para comparar previews y llegar al autor original; nunca es
  prueba suficiente de calidad o licencia.
- **Motor:** CSS native para transiciones autocontenidas; Motion.dev para gestos, springs,
  shared layout, interrupción y coreografía ligada al estado.
- **Calmado y funcional:** Beautiful UI + CSS native.
- **Limpio y moderno:** Kokonut UI, cherry-pickeado y re-vestido.
- **Fluido y premium:** beUI + Motion.dev, re-vestido con tokens propios.
- **Gráficas y datos:** Bklit, simplificando la interacción para mobile.
- **Experimental o firma visual:** React Bits o Rare UI, uno o dos acentos como máximo por flujo.
- **Semántica y accesibilidad base:** primitivos existentes; shadcn/ui es una opción, no la estética.

Si dos candidatos sólo cambian colores o radios, no son alternativas reales. Busca otra mecánica:
inline vs panel, lista vs tabla, transición nativa vs shared layout, calmada vs cinética.
